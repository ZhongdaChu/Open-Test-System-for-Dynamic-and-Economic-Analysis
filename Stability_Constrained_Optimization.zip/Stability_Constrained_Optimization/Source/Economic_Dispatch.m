function [ Sol ] = economic_dispatch( c, Pmin, Pmax, PD )
    % For a given load, given costs for each generator, 
    % given max and min generations, given total generation,
    % minimize total costs

    num_buses = length(Pmin);
    % Check the input values
    assert ( num_buses == length(Pmax), 'Pmax or Pmin is wrong length' );
    assert ( num_buses == length(c), 'c is wrong length' );
    assert ( 1 == length(PD), 'PD is wrong length' );

    P = sdpvar(num_buses,1);
    Constraints = [Pmin <= P' <= Pmax, sum(P) == PD];
    objective = c*P;

    optimize(Constraints, objective)
    Sol.P = value(P);
    Sol.obj = value(objective);
end

