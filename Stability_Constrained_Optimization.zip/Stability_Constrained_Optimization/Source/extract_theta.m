function theta = extract_theta(Vcart, linedata)

num_buses = length(Vcart);
[num_lines, ~] = size(linedata);

theta = ones(num_buses,1) * nan;
theta(1) = 0;

for k = 2 : num_buses
    for m = 1 : num_lines
        if (linedata(m,1) == k && linedata(m,2) == 1) || (linedata(m,1) == 1 && linedata(m,2) == k)
            theta(k) = angle(Vcart(k,1))*180/pi;
            break
        end
    end
end

num_missing = isnan(theta') * ones(num_buses,1);

count = 0;
while(num_missing && count < 1000)
    for k = 2 : num_buses
        if isnan(theta(k))
            for m = 1 : num_lines
                if linedata(m,1) == k && ~ isnan(theta(linedata(m,2)))
                    theta(k) = angle(Vcart(k,linedata(m,2)))*180/pi + theta(linedata(m,2));
                    break
                end
                if linedata(m,2) == k && ~ isnan(theta(linedata(m,1)))
                    theta(k) = angle(Vcart(k,linedata(m,1)))*180/pi + theta(linedata(m,1));
                    break
                end
            end
        end
    end
    
    count = count + 1;
    num_missing = isnan(theta') * ones(num_buses,1);
end
        