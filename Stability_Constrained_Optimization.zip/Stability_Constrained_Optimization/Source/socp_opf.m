function Sol = socp_opf ( c1, c2, Pmin, Pmax, Qmin, Qmax, PD, QD, Vmin, ...
    Vmax, Ybus, S_limit, Ysh, shunt_susceptances, ...
    baseMVA, PG_init, QG_init, Vm_init, Va_init, ...
    linedata, silent) 
    %   socp_opf Apply AC Optimal Power Flow Equations relaxed to an SOCP 
    
    
    % Number of buses, lines
    num_buses = length(Pmin);
    [num_lines, ~] = size(linedata);
    
    % Check the input values
    assert ( num_buses == length(Pmax), 'Pmax or Pmin is wrong length' );
    assert ( num_buses == length(Qmin), 'Qmin is wrong length' );
    assert ( num_buses == length(Qmax), 'Qmax is wrong length' );
    assert ( num_buses == length(PD), 'PD is wrong length' );
    assert ( num_buses == length(QD), 'QD is wrong length' );
    assert ( num_buses == length(Vmin), 'Vmin is wrong length' );
    assert ( num_buses == length(Vmax), 'Vmax is wrong length' );
    assert ( num_buses == length(PG_init), 'PG_init is wrong length' );
    assert ( num_buses == length(QG_init), 'QG_init is wrong length' );
    assert ( num_buses == length(Vm_init), 'Vm_init is wrong length' );
    assert ( num_buses == length(Va_init), 'Va_init is wrong length' );
    assert ( num_buses == length(c1), 'c1 is wrong length' );
    assert ( num_buses == length(c2), 'c2 is wrong length' );
    assert ( all([num_buses, num_buses] == size(Ybus)), ...
        'Ybus is wrong length' );
    assert ( all([num_buses, num_buses] == size(S_limit)), ...
        'S_limit is wrong length' );
    
    % Set up decision variables used for optimisation:
    Vcart = sdpvar(num_buses, num_buses, 'hermitian', 'complex');
    Constraints = [];
    for k = 1 : num_lines
        start_bus = linedata(k,1);
        end_bus = linedata(k,2);
        Constraints = [Constraints, ...
            Vcart(start_bus, end_bus) * conj(Vcart(start_bus, end_bus)) ...
            <= Vcart(start_bus, start_bus) * Vcart(end_bus, end_bus)];
    end
    P_node = sdpvar(num_buses, 1);
    Q_node = sdpvar(num_buses, 1);
    P_branch = sdpvar(num_buses, num_buses, 'full');
    Q_branch = sdpvar(num_buses, num_buses, 'full');
    S_branch = sdpvar(num_buses, num_buses, 'full', 'complex');
    Constraints = [Constraints, ...
        real(S_branch) == P_branch, imag(S_branch) == Q_branch];
   
    P_node_min = Pmin-PD;
    P_node_max = Pmax-PD;
    Q_node_min = Qmin-QD;
    Q_node_max = Qmax-QD;

    % Add constraints
    Constraints = [Constraints, ...
            P_node_min' <= P_node <= P_node_max', ...
            Q_node_min' <= Q_node <= Q_node_max', ...
            P_branch.^2 + Q_branch.^2 <= S_limit.^2, ...
            Vmin'.^2 <= diag(Vcart) <= Vmax'.^2, ...
            P_node == P_branch * ones(num_buses,1)
            ];

    % Includes shunt values
    for k = 1 : num_buses
        Constraints = [Constraints, ...
            Q_node(k) == Q_branch(k,:) * ones(num_buses,1) ...
            - imag(Vcart(k,k) * shunt_susceptances(k)*1i)];           
    end
    
    for k = 1 : num_buses
        for l = 1 : num_buses
            Constraints = [Constraints, ...
                S_branch(k,l) == Vcart(k,k) * conj(Ysh(k,l)) + ...
                (Vcart(k,k) - Vcart(k,l)) * conj(-Ybus(k,l))
              ];
        end
    end
    
    % Set initial values
    assign(P_node, PG_init' - PD');
    assign(Q_node, QG_init' - QD');
    [a,b] = pol2cart(Va_init'/180*pi,Vm_init');
    V_complex = a + b*1i;
    assign(Vcart, V_complex * V_complex');
    S_init = zeros(num_buses, num_buses);
    for k = 1:num_buses
        for l = 1:num_buses
            S_init(k,l) = ...
                (value(Vcart(k,k)) - value(Vcart(k,l))) * conj(-Ybus(k,l));
        end
    end
    assign(S_branch, S_init)
    assign(P_branch, real(S_init))
    assign(Q_branch, imag(S_init))
    
    % Set the objective function to be minimised
    objective = c1*((P_node+PD') * baseMVA) ...
        + c2*((P_node+PD').^2 * baseMVA^2);
  
    % Store initial values
    Sol.obj_init = value(objective);
    Sol.PG_init = value(P_node+PD');
    Sol.QG_init = value(Q_node+QD');
    Sol.V_mag_init = sqrt(diag(value(Vcart)));
    Sol.V_theta_deg_init = extract_theta(value(Vcart),linedata); 
    Sol.S_branch_init = value(S_branch);
    Sol.P_branch_init = value(P_branch);
    Sol.Q_branch_init = value(Q_branch);
    
    % Set options for the solver:
    options = sdpsettings('solver','gurobi');
    
    % Do the optimisation
    if silent
        options.verbose = false;
        tic;
        optimize(Constraints, objective, options);
    else
        tic;
        optimize(Constraints, objective, options)
    end
    Sol.time = toc;
    
    % Extract the solution
    Sol.obj = value(objective);
    Sol.PG = value(P_node+PD');
    Sol.QG = value(Q_node+QD');
    Sol.Pbranch = value(P_branch);
    Sol.Qbranch = value(Q_branch);
    Sol.Vcart = value(Vcart);
    Sol.V_mag = sqrt(diag(value(Vcart)));   
    Sol.V_theta_deg = extract_theta(value(Vcart), linedata); 

    if ~ silent
        check(Constraints)
    end
end