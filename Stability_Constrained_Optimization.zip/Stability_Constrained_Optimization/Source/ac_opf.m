function Sol = ac_opf ( c1, c2, Pmin, Pmax, Qmin, Qmax, PD, QD, Vmin, ...
    Vmax, thetamin, thetamax, Ybus, Ilinemax, S_limit, ...
    Ylineij, Ylineji, Ysh, ...
    baseMVA, iter_num, PG_init, QG_init, Vm_init, Va_init, silent) 
    %   ac_opf Apply AC Optimal Power Flow Equations
    
    % Number of buses, lines
    num_buses = length(Pmin);
    num_lines = length(Ilinemax);
    
    % Check the input values
    assert ( num_buses == length(Pmax), 'Pmax or Pmin is wrong length' );
    assert ( num_buses == length(Qmin), 'Qmin is wrong length' );
    assert ( num_buses == length(Qmax), 'Qmax is wrong length' );
    assert ( num_buses == length(PD), 'PD is wrong length' );
    assert ( num_buses == length(QD), 'QD is wrong length' );
    assert ( num_buses == length(Vmin), 'Vmin is wrong length' );
    assert ( num_buses == length(Vmax), 'Vmax is wrong length' );
    assert ( num_buses == length(thetamin), 'thetamin is wrong length' );
    assert ( num_buses == length(thetamax), 'thetamax is wrong length' );
    assert ( num_buses == length(PG_init), 'PG_init is wrong length' );
    assert ( num_buses == length(QG_init), 'QG_init is wrong length' );
    assert ( num_buses == length(Vm_init), 'Vm_init is wrong length' );
    assert ( num_buses == length(Va_init), 'Va_init is wrong length' );
    assert ( num_buses == length(c1), 'c1 is wrong length' );
    assert ( num_buses == length(c2), 'c2 is wrong length' );
    assert ( all([num_buses, num_buses] == size(Ybus)), ...
        'Ybus is wrong length' );
    assert ( all([num_lines, num_buses] == size(Ylineij)), ...
        'Ylineij is wrong length');
    assert ( all([num_lines, num_buses] == size(Ylineji)), ...
        'Ylineji is wrong length');
    
    % Set up decision variables used for optimisation:
    Vreal = sdpvar(num_buses, 1);
    Vimag = sdpvar(num_buses, 1);
    Vcart = sdpvar(num_buses,1,'full','complex');
    Constraints = [real(Vcart) == Vreal, imag(Vcart) == Vimag];
    
    PG = sdpvar(num_buses, 1);
    QG = sdpvar(num_buses, 1);
    SGcart = sdpvar(num_buses,1,'full','complex');
    Constraints = [Constraints, real(SGcart) == PG, imag(SGcart) == QG];
    

    SD = transpose(PD + sqrt(-1)*QD);

    % Add constraints
    Constraints = [Constraints, Vimag(1) == 0, Vreal(1) >= 0]; 
    % This is equivalent to setting theta=0 in the slack bus
    Vmag = sqrtm(Vreal.^2+Vimag.^2);
    for k = 1 : num_buses
        Constraints = [Constraints, Pmin(k) <= PG(k) <= Pmax(k)];
        Constraints = [Constraints,...
            Vmin(k) <= Vmag(k) <= Vmax(k)]; 
        Constraints = [Constraints, Qmin(k) <= QG(k) <= Qmax(k)];
        if k ~= 1
            if (thetamax(k)-thetamin(k)<2*pi-0.05) 

                Constraints = [Constraints,...
                    tan(thetamin(k)) <= Vimag./Vreal <= tan(thetamax(k))];
            end
        end
    end

    % Line current limits
    Constraints = [Constraints, ...
        sqrtm(real(Ylineij * Vcart).^2+imag(Ylineij * Vcart).^2) <= Ilinemax, ...
        sqrtm(real(Ylineji * Vcart).^2+imag(Ylineji * Vcart).^2) <= Ilinemax];
    
%     Apparent flow limits
    Vcart_conj = Vcart-2*sqrt(-1)*imag(Vcart);
    Constraints = [Constraints, ... 
        add_network_constraints_AC(...
        S_limit, Vcart, Vcart_conj, conj(Ybus), conj(Ysh) ) ];
    
    % AC flow (power balance)
    for k=1:length(PG)
        Constraints = [Constraints, ...
            SGcart(k) - SD(k) ==  ...
            Vcart(k)*conj(Ybus(k,:))*Vcart_conj ];
    end
  
    % Set initial values
    assign(PG, PG_init');
    assign(QG, QG_init');
    Vreal_init = Vm_init .* cos(Va_init / 360 * 2 * pi);
    Vimag_init = Vm_init .* sin(Va_init / 360 * 2 * pi);
    assign(Vreal, Vreal_init');
    assign(Vimag, Vimag_init');
    assign(Vcart, value(Vreal) + 1i*value(Vimag));
    assign(SGcart, value(PG) + 1i* value(QG));
    
    % Set the objective function to be minimised
    objective = c1*(PG * baseMVA) + c2*(PG.^2 * baseMVA^2);
    
    % Store initial values
    Sol.obj_init = value(objective);
    Sol.PG_init = value(PG);
    Sol.QG_init = value(QG);
    Sol.V_mag_init = value(Vmag);
    Sol.V_theta_deg_init = angle(value(Vreal)+1i*value(Vimag)) *180/pi;
    Sol.SGcart_init = value(SGcart);
    Sol.Vcart_init = value(Vcart);
    Sol.Vcart_conj_init = value(Vcart_conj);
    Sol.Vimag_init = value(Vimag);
    Sol.Vreal_init = value(Vreal);
    
    
    % Set options for the solver:
    options = sdpsettings('solver','bmibnb','bmibnb.maxiter',iter_num, ...
        'bmibnb.maxtime', 8*3600);
% options = sdpsettings('solver', 'fmincon', 'fmincon.MaxIter', 1000,'usex0',1);
%     options = sdpsettings('solver', 'filtersd'); 
%     options = sdpsettings('solver', 'ipopt', 'ipopt.max_iter', 10000); 
%     options = sdpsettings('solver', 'nomad'); 
    
    % Do the optimisation
    if silent
        options.verbose = false;
        tic;
        optimize(Constraints, objective, options);
    else
        tic;
        optimize(Constraints, objective, options)
    end
    Sol.time = toc;
    
    % Extract the solution
    Sol.obj = value(objective);
    Sol.PG = value(PG);
    Sol.QG = value(QG);
    Sol.V_mag = abs(value(Vcart));
    Sol.V_theta_deg = angle(value(Vcart))*180/pi;
    Sol.Vimag = value(Vimag);
    Sol.Vreal = value(Vreal);
    for k = 1 : num_buses
        for m = 1 : num_buses
            Sol.S_branch(k,m) = ...
                - value(Vcart(k)) * conj(value(Vcart(k) ...
                - Vcart(m))) * conj(Ybus(k,m)) + ...
                value(conj(Ysh(k,m)) * Vcart(k) ...
            * Vcart_conj(k));
        end
    end

    if ~ silent
        check(Constraints)
    end
end