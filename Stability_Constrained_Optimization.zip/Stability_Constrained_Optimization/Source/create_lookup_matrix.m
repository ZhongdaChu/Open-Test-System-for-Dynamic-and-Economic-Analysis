function [ lookup_matrix ] = create_lookup_matrix( asset_to_bus, num_bus )
%create_lookup_matrix Creates a matrix with 1 for where there's a link
%between the asset and the bus. 
    lookup_matrix = zeros(length(asset_to_bus),num_bus); % asset_num, bus_num
    for i = 1 : length(asset_to_bus)
        lookup_matrix(i, asset_to_bus(i)) = 1;
    end

end

