function [ Sol ] = run_OPF(settings, c1, c2, Pmin, Pmax, Qmin, Qmax, ...
    PD, QD, Vmin, Vmax, thetamin, thetamax, Ybus, Ilinemax, S_limit, ...
    Ylineij, Ylineji, Ysh, baseMVA, linedata, ...
    PG_init, QG_init, Vm_init, Va_init, shunt_susceptances)

switch settings.OPF_type
    case 'DC'
        B = create_Bbus(linedata);
        Sol = dc_opf ( c1, Pmin, Pmax, PD, S_limit, B, baseMVA, ...
            settings.silent );
        Sol.QG = zeros(length(Sol.PG),1);
        Sol.V_mag = ones(length(Sol.PG),1);
    case 'AC'
        Sol = ac_opf ( c1, c2, Pmin, Pmax, Qmin, Qmax, PD, QD, ...
            Vmin, Vmax, thetamin, thetamax, Ybus, Ilinemax, S_limit, ...
            Ylineij, Ylineji, Ysh, baseMVA, settings.iter_num, PG_init, ...
            QG_init, Vm_init, Va_init, settings.silent);
    case 'SDP'
        Sol = sdp_opf ( c1, c2, Pmin, Pmax, Qmin, Qmax, PD, QD, ...
            Vmin, Vmax, Ybus, S_limit, Ysh, shunt_susceptances, ...
            baseMVA, PG_init, QG_init, ...
            Vm_init, Va_init, settings.silent);

    case 'SOCP'
        Sol = socp_opf ( c1, c2, Pmin, Pmax, Qmin, Qmax, PD, QD, ...
            Vmin, Vmax, Ybus, S_limit, Ysh, shunt_susceptances, ...
            baseMVA, PG_init, QG_init, ...
            Vm_init, Va_init, linedata, settings.silent);
    otherwise
        warning('Unsupported OPF type in settings')
end

Objective = Sol.obj;
PG = Sol.PG*baseMVA ;
QG = Sol.QG*baseMVA;
V_mag = Sol.V_mag;
V_theta_deg = Sol.V_theta_deg;

if ~ settings.silent
    PG 
    QG 
    V_mag
    V_theta_deg
    Objective 
end
    