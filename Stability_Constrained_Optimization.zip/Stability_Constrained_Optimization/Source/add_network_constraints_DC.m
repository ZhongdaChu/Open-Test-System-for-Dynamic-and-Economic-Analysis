function [ NetworkConstraints ] = add_network_constraints_DC ( ...
    B, theta, Pijmax, PG, PD )
    NetworkConstraints = B*theta == PG - PD;
    num_gen = length(PG);
    for i = 1 : num_gen
        for j = 1 : num_gen
            NetworkConstraints = [NetworkConstraints, ...
                B(i,j) * ( theta(i) - theta(j) ) <= Pijmax(i,j)];
        end
    end
                
end

