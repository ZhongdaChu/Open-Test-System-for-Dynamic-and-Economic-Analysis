function Sol = ...
    dc_opf ( c, Pmin, Pmax, PD, Pijmax, B, baseMVA, silent )
    %   dc_opf Apply DC Optimal Power Flow Equations
    
    %   Minimise the cost of the power generation given a load, costs for
    %   each generator and max and min generation as well as line ratings
    
    % Number of buses
    size = length(Pmin);
    
    % Check the input values
    assert ( size == length(Pmax), 'Pmax or Pmin is wrong length' );
    assert ( size == length(PD), 'PD is wrong length' );
    assert ( size == length(c), 'c is wrong length' );
    assert ( size == length(Pijmax(:,1)), 'Pijmax is wrong length' );
    assert ( size == length(Pijmax(1,:)), 'Pijmax is wrong length' );
    assert ( size == length(B(:,1)), 'B is wrong length' );
    assert ( size == length(B(1,:)), 'B is wrong length' );

    % Set up variables used for optimisation
    PG = sdpvar(size, 1);
    theta = sdpvar(size, 1);
    
    % Add constraints
    Constraints = [theta(1) == 0]; % Angles are relative to something
    for i = 1 : size % Generation must be within bounds for each generator
        Constraints = [Constraints, Pmin(i) <= PG(i) <= Pmax(i)];
    end
    % Generation and consumption should balance
    Constraints = [Constraints, sum(PG) == sum(PD)]; 
    
    % Check that power is transfered where it's needed
    % Check that the transfer between generator busses does not exceed
    % what the line can carry
    NetworkConstraints = add_network_constraints_DC ( ...
    B, theta, Pijmax, PG, PD' );

    Constraints = [Constraints, NetworkConstraints];
    
    % Set the objective function to be minimised
    objective = c*PG*baseMVA;

    % Do the optimisation
    
    if silent
        options = sdpsettings('verbose', false);
        tic;
        optimize(Constraints, objective, options);
    else
        tic;
        optimize(Constraints, objective)
    end
    Sol.time = toc;
    % Extract the solution
    Sol.PG = value(PG);
    Sol.obj = value(objective);
    Sol.V_theta_deg = value(theta)*180/pi;
    Sol.theta = value(theta);
    for a = 1 : size
        for b = 1 : size
            Sol.flow(a,b) = B(a,b) * (value(theta(a)) - value(theta(b)) );
        end
    end
end