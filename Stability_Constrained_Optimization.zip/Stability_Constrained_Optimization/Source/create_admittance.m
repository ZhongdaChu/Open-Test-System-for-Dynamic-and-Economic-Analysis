function [G, B] = create_admittance(linedata, shunt_susceptances)
%CREATE_ADMITTANCE forms admittance matrix for given linedata and shunt_susceptances
%                                    Line code
%          Bus bus  R    X   1/2 B   = 1 for lines
%           nl nr  pu   pu     pu    >1 or <1 tr. tap at bus nl
    num_bus = max(max(linedata(:,1:2)));
    num_branch = size(linedata, 1);
    Y = zeros(num_bus, num_bus);
    for i = 1: num_branch
        Y_pi1 = (linedata(1, 6) - 1) / (linedata(i, 6) * (linedata(i, 3) + 1i * linedata(i, 4)));
        Y_pi2 = (1 - linedata(i, 6)) / (linedata(i, 6) ^ 2 *  (linedata(i, 3) + 1i * linedata(i, 4)));
        Z_pi = linedata(i, 6) *  (linedata(i, 3) + 1i * linedata(i, 4));
        
        Y(linedata(i, 1), linedata(i, 1)) = Y(linedata(i, 1), linedata(i, 1)) + Y_pi1 + 1 / Z_pi + 1i * linedata(i, 5);
        Y(linedata(i, 2), linedata(i, 2)) = Y(linedata(i, 2), linedata(i, 2)) + Y_pi2 + 1 / Z_pi + 1i * linedata(i, 5);
        Y(linedata(i, 1), linedata(i, 2)) = -1/Z_pi;
        Y(linedata(i, 2), linedata(i, 1)) = -1/Z_pi;
    end
    for i = 1: num_bus
        Y(i, i) = Y(i, i) + 1i * shunt_susceptances(i);
    end
    G = real(Y);
    B = imag(Y);
end

