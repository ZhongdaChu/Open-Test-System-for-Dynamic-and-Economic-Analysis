function [Ylineij, Ylineji] = create_Yline(linedata, shunt_susceptances)

% Based on create_Ybus
%% Get inputs
nl = linedata(:,1); 
nr = linedata(:,2); 
R = linedata(:,3);
X = linedata(:,4); 
Bc = 1i*linedata(:,5); 
a = linedata(:, 6);
num_lines = length(linedata(:,1)); 
num_buses = max(max(nl), max(nr));

Z = R + 1i*X; 
y = ones(num_lines,1)./Z;        %branch admittance
  
%%
for i=1:num_lines
    if a(i) <= 0
        error(['Error in tap ' num2str(i) ...
            ' in "linedata", the tap cannot be negative'])
    end
end
    
Ylineij = zeros(num_lines,num_buses); % Initialize Ylineij to zero
Ylineji = zeros(num_lines,num_buses); % Initialize Ylineji to zero
    
% Find the shunt values for each bus
Ysh = zeros(num_buses,1);
for j=1:num_lines
    Ysh(nl(j)) = Ysh(nl(j)) + Bc(j);
    Ysh(nr(j)) = Ysh(nr(j)) + Bc(j);
end

for j=1:num_buses
    Ysh(j) = Ysh(j) + shunt_susceptances(j)*1i;
end

% Fill in the Yline matrices
for j=1:num_lines
    Ylineij(j,nl(j))=y(j)/a(j) + Ysh(nl(j));
    Ylineij(j,nr(j))=-y(j)/a(j);
    
    Ylineji(j,nl(j))=-y(j)/a(j);
    Ylineji(j,nr(j))=y(j)/a(j) + Ysh(nr(j));
end

end
