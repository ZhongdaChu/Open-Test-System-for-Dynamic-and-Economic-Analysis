function Sol = ac_opf ( c1, c2, Pmin, Pmax, Qmin, Qmax, PD, QD, Vmin, Vmax, ...
    thetamin, thetamax, Ybus, Ilinemax, Ylineij, Ylineji, baseMVA)  
    tic;
    %   ac_opf Apply AC Optimal Power Flow Equations
    
    %   Fuller description
    %   http://www.chatziva.com/31xxx/Lectures/Lecture7.pdf
    
    % Number of busses
    num_buses = length(Pmin);
    num_lines = length(Ilinemax);
    
    % Check the input values
    assert ( num_buses == length(Pmax), 'Pmax or Pmin is wrong length' );
    assert ( num_buses == length(Qmin), 'Qmin is wrong length' );
    assert ( num_buses == length(Qmax), 'Qmax is wrong length' );
    assert ( num_buses == length(PD), 'PD is wrong length' );
    assert ( num_buses == length(QD), 'QD is wrong length' );
    assert ( num_buses == length(Vmin), 'Vmin is wrong length' );
    assert ( num_buses == length(Vmax), 'Vmax is wrong length' );
    assert ( num_buses == length(thetamin), 'thetamin is wrong length' );
    assert ( num_buses == length(thetamax), 'thetamax is wrong length' );
    assert ( num_buses == length(c1), 'c1 is wrong length' );
    assert ( num_buses == length(c2), 'c2 is wrong length' );
    assert ( num_buses == length(Ybus(:,1)), 'Ybus is wrong length' );
    assert ( num_buses == length(Ybus(1,:)), 'Ybus is wrong length' );
    assert ( num_buses == length(Ylineij(1,:)),'Ylineij is wrong length');
    assert ( num_lines == length(Ylineij(:,1)),'Ylineij is wrong length' );
    assert ( num_buses == length(Ylineji(1,:)),'Ylineji is wrong length');
    assert ( num_lines == length(Ylineji(:,1)),'Ylineji is wrong length' );
    
    % Set up decision variables used for optimisation:
    Vreal = sdpvar(num_buses, 1);
    Vimag = sdpvar(num_buses, 1);
    % This is how to declare complex variables, although I think it also
    % works if you don't specify the "sdpvar" as complex:
    % (from https://yalmip.github.io/tutorial/complexproblems/)
    Vcart = sdpvar(num_buses,1,'full','complex');
    Constraints = [real(Vcart) == Vreal, imag(Vcart) == Vimag];
    
    % NOTE: it is not possible to use functions like "pol2cart" in YALMIP,
    % although it might be possible to implement it using the info in 
    % https://yalmip.github.io/command/sdpfun/
    %
    % I think that for using complex variables in YALMIP, you can only
    % handle the rectangular form (not sure), so it might be better to
    % change the formulation of our constraints to consider the rectangular
    % form for every complex variable (this formulation can be found
    % online, for example here
    % http://www.tandfonline.com/doi/full/10.1080/0740817X.2016.1189626).
    % However, the code here considers the formulation in
    % http://www.chatziva.com/31xxx/Lectures/Lecture7.pdf which mixes
    % rectangular and polar forms.
    %
    % In general, it is not possible to use even common functions such as
    % "sin" or "abs" in non-convex formulations, because YALMIP assumes
    % convexity when translating these Matlab functions into the particular
    % solver, so that the model is solved efficiently. For more info about
    % this, check these links:
    % https://groups.google.com/forum/#!topic/yalmip/Y6-9tJw-Wcw
    % https://yalmip.github.io/tutorial/nonlinearoperatorscallback/
    % https://groups.google.com/forum/#!topic/yalmip/eJidaJgI9ec
    % 
    % Therefore, the constraints have to be reformulated so that they don't
    % use these functions. For example, use "sqrtm" instead of "sqrt", read
    % the last URL above to understand why.
    %
    % When in doubt, use YALMIP's forum to ask for help.
    
    % Finish stting up variables:
    PG = sdpvar(num_buses, 1);
    QG = sdpvar(num_buses, 1);
    SGcart = sdpvar(num_buses,1,'full','complex');
    Constraints = [Constraints, real(SGcart) == PG, imag(SGcart) == QG];
    
    % CAREFUL, THE NEXT LINE IS WRONG. For the line limits, we have to use
    % the complex power "S", not just its magnitude.
%     SD = sqrt(PD .* PD + QD .* QD)';
    SD = transpose(PD + sqrt(-1)*QD);

    % Add constraints
    Constraints = [Constraints, Vimag(1) == 0, Vreal(1) >= 0]; % This is equivalent to setting theta=0 in the slack bus
    Vmag = sqrtm(Vreal.^2+Vimag.^2);
    for k = 1 : num_buses
        Constraints = [Constraints, Pmin(k) <= PG(k) <= Pmax(k)];
        Constraints = [Constraints,...
            Vmin(k) <= Vmag(k) <= Vmax(k)]; % abs(Vcart(k)) = sqrtm(Vreal.^2+Vimag.^2)
        Constraints = [Constraints, Qmin(k) <= QG(k) <= Qmax(k)];
        if k ~= 1
            if (thetamax(k)-thetamin(k)<2*pi-0.05) 
                % If there are no limits for voltage angle in that bus, 
                % don't implement a constraint. It makes the optimisation
                % more efficient (because there are less constraints), but
                % in any case it would not be possible to implement a
                % constraint 0<theta<2pi in the way I do it here:
                Constraints = [Constraints,...
                    tan(thetamin(k)) <= Vimag./Vreal <= tan(thetamax(k))];
                % Since it is not possible to use "atan" in this nonconvex
                % model, I have defined the constraints like this. This
                % will only work if the angles limits, "thetamin" and 
                % "thetamax", are less than pi-radians apart.
                %
                % I think this can work, if angle limits in the power
                % system are only defined for generators, which cannot
                % consume real power, so the angle limits cannot be more
                % than pi-rads apart. THINK about this carefully, if this
                % is not true, try to implement the angle limit constraints
                % by using "tan" in "sdpfun".
            end
        end
    end

    % Line current limits:
%     Constraints = [Constraints, ...
%         abs(Ylineij * Vcart) <= Ilinemax, ...
%         abs(Ylineji * Vcart) <= Ilinemax];
% The above is not a possible implementation, it can be implemented as:
    Constraints = [Constraints, ...
        sqrtm(real(Ylineij * Vcart).^2+imag(Ylineij * Vcart).^2) <= Ilinemax, ...
        sqrtm(real(Ylineji * Vcart).^2+imag(Ylineji * Vcart).^2) <= Ilinemax];
    
    % AC flow (power balance)
%     Constraints = [Constraints, ...
%         abs(SGcart) - SD ==  ...
%         diag(Vcart)*conj(Ybus)*conj(Vcart) ];
% The above is not a possible implementation, it can be implemented as:
% (remember that "diag" cannot be used).
% ALSO, THERE IS AN ERROR ABOVE, it's "SGcart" and not "abs(SGcart)"
    Vcart_conj = Vcart-2*sqrt(-1)*imag(Vcart);
    for k=1:length(PG)
        Constraints = [Constraints, ...
            SGcart(k) - SD(k) ==  ...
            Vcart(k)*conj(Ybus(k,:))*Vcart_conj ];
    end

    % Set the objective function to be minimised
    objective = c1*(PG * baseMVA) + c2*(PG.^2 * baseMVA^2);
    
    % Set options for the solver:
    
%     % 1) Local solver:
%     options = sdpsettings('solver', 'fmincon', 'fmincon.MaxIter', 1000);

%     % You can specify  an initial guess for this local solver reading
%     % this: https://yalmip.github.io/Initials
%     assign(PG,[450/100 0]'); % baseMVA = 100
%     assign(QG,[160/100 0]'); % baseMVA = 100
%     options = sdpsettings('solver', 'fmincon', 'fmincon.MaxIter', 1000,'usex0',1);
    
    % 2) Global solver:
    options = sdpsettings('solver','bmibnb','bmibnb.maxiter',10000);

    % Do the optimisation
    optimize(Constraints, objective, options)
    
    % Extract the solution
    Sol.obj = value(objective);
    Sol.PG = value(PG);
    Sol.QG = value(QG);
    Sol.V_mag = abs(value(Vcart));
    Sol.V_theta_deg = angle(value(Vcart))*180/pi;

    check(Constraints)
    toc;
end
