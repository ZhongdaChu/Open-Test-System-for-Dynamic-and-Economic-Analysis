function [Ybr, Ysh] = create_Ybr(linedata, shunt_susceptances)

    % Original code provided by Luis Badesa Bernardo,
    % then modified by Zhongda Chu
    % then modified by Zhuoxuan Li to create Y matrix in MILP-formulated UC problem
    
    %% Get inputs
    nl = linedata(:,1); 
    nr = linedata(:,2); 
    R = linedata(:,3);
    X = linedata(:,4); 
    Bc = 1i*linedata(:,5); 
    a = linedata(:, 6);
    num_lines = length(linedata(:,1)); 
    num_buses = max(max(nl), max(nr));

    Z = R + 1i*X; 
    y = ones(num_lines,1)./(a .* Z);        % branch admittance   % irrelevant to a ???
  
    [num_lines, ~] = size(linedata);

    

%     for i=1:num_lines
%         if a(i) <= 0
%             error(['Error in tap ' num2str(i) ...
%                 ' in "linedata", the tap cannot be negative'])
%         end
%     end

    Ybr = zeros(num_buses,num_buses); % Initialize Ybus to zero

    % Fill in the off-diagonal elements
    for j=1:num_lines
        Ybr(nl(j),nr(j)) = y(j);
        Ybr(nr(j),nl(j)) = y(j);
    end
    
    Ysh = zeros(num_buses, num_buses);
    for k = 1 : num_lines
        i1 = linedata(k, 1);
        i2 = linedata(k, 2);
        Ysh(i1, i1) = Ysh(i1, i1) + 1i * linedata(k, 5) +  y(k) * (1 / (a(k)) ^ 2 - 1 / a(k));
        Ysh(i2, i2) = Ysh(i2, i2) + 1i * linedata(k, 5) + y(k) * (1 - 1 / a(k));
    end
    
    Ysh = Ysh + 1i * diag(shunt_susceptances);
    
%     % Fill in the diagonal elements
%     for  i=1:num_buses
%          for j=1:num_lines
%              if nl(j)==i
%                 Ybus(i,i) = Ybus(i,i)+y(j)/(a(j)^2) + Bc(j);
%              elseif nr(j)==i
%                 Ybus(i,i) = Ybus(i,i)+y(j) + Bc(j);
%              end
%          end
%          Ybus(i,i) = Ybus(i,i) + shunt_susceptances(i)*1i;
%     end
    
end
