function [Bbus] = create_Bbus(linedata)

% Original code provided by Luis Badesa Bernardo,
% then modified

%% Get inputs
nl = linedata(:,1); 
nr = linedata(:,2); 
X = linedata(:,4); 
Bc = 1*linedata(:,5); 
a = linedata(:, 6);
num_lines = length(linedata(:,1)); 
num_buses = max(max(nl), max(nr));

y = ones(num_lines,1)./X;        %branch admittance
  
%%
for i=1:num_lines
    if a(i) <= 0
        error(['Error in tap ' num2str(i) ...
            ' in "linedata", the tap cannot be negative'])
    end
end
    
Bbus = zeros(num_buses,num_buses); % Initialize Bbus to zero
    
% Fill in the off-diagonal elements
for j=1:num_lines
    Bbus(nl(j),nr(j))=Bbus(nl(j),nr(j))-y(j)/a(j);
    Bbus(nr(j),nl(j))=Bbus(nl(j),nr(j));
end

% Fill in the diagonal elements
for  i=1:num_buses
     for j=1:num_lines
         if nl(j)==i
            Bbus(i,i) = Bbus(i,i)+y(j)/(a(j)^2);
         elseif nr(j)==i
            Bbus(i,i) = Bbus(i,i)+y(j);
         end
     end
end

end
