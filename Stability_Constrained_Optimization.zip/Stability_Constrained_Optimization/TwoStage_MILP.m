clearvars
clc

% SystemParameters_MNE39bus
% NetworkParameters_MNE39bus

tic

% Each generator must be defined individually, as each generator is
% associated with a binary commitment decision.


%% Input parameters
load('SystemParameters.mat')
load('NetworkParameters.mat');
load('LUT_39_VS.mat')   % [1 forming SG]
load('LUT_39_SSS.mat')  % [1 [forming SG] [forming SG]*wind wind]
load('LUT_39_SCC.mat')  % [1 SG wind]
load('LUT_39_SCC_SOC_A.mat')  % [1 SG wind]
load('LUT_39_SCC_SOC_C.mat')  % [1 SG wind]

load('Isc_lim_new.mat')


%% Set up 
Td_unique = unique(Td); % Eliminate repeated entries

% Calculate the highest possible system's inertia
%SoC_init = 0.5;

for d=1:days
    %% Inputs
    load('SystemParameters.mat')
    
    clear Demand
    if stageN == 24
        Wind_tree_active = Wind_scenarios_day_active{d};
        Wind_tree_reactive = Wind_scenarios_day_reactive{d};
        Demand_active = Demand_day_active{d}';
        Demand_reactive = Demand_day_reactive{d}';
    else
        Wind_tree_active = Wind_scenarios_day_active{d}(stage0);
        Wind_tree_reactive = Wind_scenarios_day_reactive{d}(stage0);
        Demand_active = Demand_day_active{d}(stage0);
        Demand_reactive = Demand_day_reactive{d}(stage0);
    end
    %% Define the optimisation model:
    H = [];
    Total_FR_by_qss = [];
    Deloading_definition = [];
    %     Load_balance = [];
    Aux_constraints = [];
    Constraints_Gen_limits = [];
    Constraints_Ramp_limits = [];
    Constraints_Updown_time = [];
    Rocof_constraints = [];
    Nadir_constraints = [];
    qss_constraints = [];
    Cost_node = [];
    Node_constraints = [];
    Network_constraints = [];
    SOCP_constraints = [];
    
    VS_constraints = [];
    SSS_constraints = [];
    SCC_constraints = [];
    dV_constraints = [];
    
    Feature_constraints = [];
    DataDriven_Nadir = [];
    DataDriven_RoCoF = [];
    DataDriven_QssFreq = [];
    
    Voltage_constraints = [];
    stages = stageN;
%     stages = 1;
    Hs = sdpvar(scenarios,stages,'full');    %SI from WTs

    for k=1:stages
        y{k} = binvar(scenarios, num_gen);
    end
    
    for k=1: stages        
        %% Define DVs
        Wind_curtailed_active{k} = sdpvar(scenarios,num_wind,'full');
        Qw{k} = sdpvar(scenarios,num_GFL,'full');
        Wind_curtailed_reactive{k} = sdpvar(scenarios,num_wind,'full');
        %         PV_curtailed_active{k} = sdpvar(scenarios,num_PV,'full');
        %         PV_curtailed_reactive{k} = sdpvar(scenarios,num_PV,'full');
        Load_curtailed_active{k} = sdpvar(scenarios,num_load,'full');
        Load_curtailed_reactive{k} = sdpvar(scenarios,num_load,'full');
        
        Aux_constraints = [Aux_constraints,...
            zeros(scenarios,num_wind) <= Wind_curtailed_active{k} ...
            <= Wind_tree_active{k}, ...
            zeros(scenarios,num_GFM) == Wind_curtailed_active{k}(:,1:num_GFM), ...
            Qw{k}.^2 + (Wind_tree_active{k}(:,num_GFM+1:end) - Wind_curtailed_active{k}(:,num_GFM+1:end)).^2 ...
            <= (Wind_capacity/num_wind).^2, ...    
            zeros(scenarios,num_load) <= Load_curtailed_active{k} ...
            <= ones(scenarios,1)*Demand_active{k}
            %             zeros(scenarios,num_PV) <= PV_curtailed_active{k} ...           %             <= PV_tree_active{k}, ...
            ];
        if VS_Q == 0
            Aux_constraints = [Aux_constraints, zeros(scenarios,num_GFL) == Qw{k}];
        else
            Aux_constraints = [Aux_constraints, zeros(scenarios,num_GFL) <= Qw{k} ...
                <= Wind_tree_active{k}(:,num_GFM+1:end) - Wind_curtailed_active{k}(:,num_GFM+1:end)];
        end
        for s = 1:scenarios
            for n = 1:num_wind
                if Wind_tree_reactive{k}(s,n) >= 0
                    Aux_constraints = [Aux_constraints, ...
                        0 <= Wind_curtailed_reactive{k}(s,n) <= Wind_tree_reactive{k}(s,n)
                        ];
                else
                    Aux_constraints = [Aux_constraints, ...
                        Wind_tree_reactive{k}(s,n) <= Wind_curtailed_reactive{k}(s,n) <= 0
                        ];
                end
            end
            
            for n = 1:num_load
                if Demand_reactive{k}(n) >= 0
                    Aux_constraints = [Aux_constraints, ...
                        0 <= Load_curtailed_reactive{k}(s,n) <= Demand_reactive{k}(n)
                        ];
                else
                    Aux_constraints = [Aux_constraints, ...
                        Demand_reactive{k}(n) <= Load_curtailed_reactive{k}(s,n) <= 0
                        ];
                end
            end
        end   %Curtailed reactive power limits
        % Defining bus voltage magnitudes V and angles theta as column
        % vectors for simplicity
        V{k} = sdpvar(num_bus, scenarios, 'full');
        theta{k} = sdpvar(num_bus, scenarios, 'full');
                
        Pw_eq{k} = sdpvar(scenarios,num_GFL,'full');
        Qw_eq{k} = sdpvar(scenarios,num_GFL,'full');
        Gamma_eq{k} = sdpvar(scenarios,num_GFL,'full');
        Lambda{k} = [];
        Isc{k} = sdpvar(scenarios,num_bus,'full');
        
        if DC == 1
            P_node{k} = sdpvar(scenarios,num_bus,'full');
            Q_node{k} = sdpvar(scenarios,num_bus,'full');
            PG{k} = sdpvar(scenarios,num_bus,'full');
            QG{k} = sdpvar(scenarios,num_bus,'full');
            PD{k} = sdpvar(scenarios,num_bus,'full');
            QD{k} = sdpvar(scenarios,num_bus,'full');
            Node_constraints = [Node_constraints, P_node{k} == PG{k} - PD{k}, ... % Constraint (23a - 1)
                Q_node{k} == QG{k} - QD{k}];    % Constraint (23b - 1)
            for m = 1:scenarios
                for n = 1 : num_bus
                    Constr1 =  P_node{k}(m, n) == Gbr(n, :) * ones(num_bus, 1) * (2 * V{k}(n, m) - 1) -(Gbr(n, :) * ones(num_bus, 1) * (V{k}(n, m) - 1)) - Gbr(n, :) * V{k}(:, m) - (Bbr(n, :) * ones(num_bus, 1) * theta{k}(n, m) - Bbr(n, :) * theta{k}(:, m)); % Constraint (22a)
                    Node_constraints = [Node_constraints Constr1];
                    Constr2 = Q_node{k}(m, n) == Bbr(n, :) * ones(num_bus, 1) * (1 - 2 * V{k}(n, m)) + (Bbr(n, :) * ones(num_bus, 1) * (V{k}(n, m) - 1)) + Bbr(n, :) * V{k}(:, m) - (Gbr(n, :) * ones(num_bus, 1) * theta{k}(n, m) - Gbr(n, :) * theta{k}(:, m)); % Constraint (22b)
                    Node_constraints = [Node_constraints Constr2];
                    Voltage_constraints =  [Voltage_constraints, V{k}(n, m) >= Vmin, V{k}(n, m) <= Vmax];
                end
            end
        else
            P_node{k} = sdpvar(scenarios,num_bus,'full');
            Q_node{k} = sdpvar(scenarios,num_bus,'full');
            PG{k} = sdpvar(scenarios,num_bus,'full');
            QG{k} = sdpvar(scenarios,num_bus,'full');
            PD{k} = sdpvar(scenarios,num_bus,'full');
            QD{k} = sdpvar(scenarios,num_bus,'full');
            
            for m = 1:scenarios
                Vcart{k}{m} = sdpvar(num_bus,num_bus,'hermitian','complex');
                Vcart_conj{k}{m} = Vcart{k}{m}-2*sqrt(-1)*imag(Vcart{k}{m});
                for n = 1 : num_lines
                    start_bus = linedata(n,1);
                    end_bus = linedata(n,2);
                    SOCP_constraints = [SOCP_constraints, ...
                        Vcart{k}{m}(start_bus, end_bus) * Vcart_conj{k}{m}(start_bus, end_bus) ...
                        <= Vcart{k}{m}(start_bus, start_bus) * Vcart{k}{m}(end_bus, end_bus)];
                end
                P_branch{k}{m} = sdpvar(num_bus,num_bus,'full');
                Q_branch{k}{m} = sdpvar(num_bus,num_bus,'full');
                S_branch{k}{m} = sdpvar(num_bus,num_bus,'full','complex');
                Aux_constraints = [Aux_constraints, ...
                    real(S_branch{k}{m}) == P_branch{k}{m}, ...
                    imag(S_branch{k}{m}) == Q_branch{k}{m}
                    ];            
            end

                        
            Node_constraints = [Node_constraints, P_node{k} == PG{k} - PD{k}, ...
                Q_node{k} == QG{k} - QD{k}];
            
            for m = 1:scenarios
                Node_constraints = [Node_constraints, ...
                    P_branch{k}{m}.^2 + Q_branch{k}{m}.^2 <= S_limit.^2, ...
                    Vmin.^2 <= diag(Vcart{k}{m}) <= Vmax.^2, ...
                    P_node{k}(m,:) == transpose(P_branch{k}{m} * ones(num_bus,1))
                    ];
                
                for n = 1 : num_bus
                    Node_constraints = [Node_constraints, ...
                        Q_node{k}(m,n) == Q_branch{k}{m}(n,:) * ones(num_bus,1) ...
                        - imag(Vcart{k}{m}(n,n) * shunt_susceptances(n)*1i)];
                end
            end
            
            for m = 1:scenarios
                for n = 1:num_bus
                    for p = 1:num_bus
                        Network_constraints = [Network_constraints, ...
                            S_branch{k}{m}(n,p) == Vcart{k}{m}(n,n) ...
                            * Ysh_conj(n,p) ...
                            + (Vcart{k}{m}(n,n) - Vcart{k}{m}(n,p)) * ...
                            (- Ybus_conj(n,p))
                            ];
                    end
                end
            end
        end
        
        
        xa{k} = sdpvar(scenarios, num_gen, 'full'); % active power of gens
        xr{k} = sdpvar(scenarios, num_gen, 'full'); % reactive power of gens
        
        Node_constraints = [Node_constraints, ...
            PG{k} == ...
            xa{k} * net.genMat + Wind_tree_active{k} * net.windMat ...
            - Wind_curtailed_active{k} * net.windMat, ...
            QG{k} == ...
            xr{k} * net.genMat + Wind_tree_reactive{k} * net.windMat ...
            - Wind_curtailed_reactive{k} * net.windMat];
        Node_constraints = [Node_constraints, ...
            PD{k} == ...
            ones(scenarios,1) * Demand_active{k} * net.loadMat - ...
            Load_curtailed_active{k} * net.loadMat, ...
            QD{k} == ...
            ones(scenarios,1) * Demand_reactive{k} * net.loadMat - ...
            Load_curtailed_reactive{k} * net.loadMat, ...
            ];
        
        % Fix commitment decision of inflexible_gen to be same as in the first
        % scenario in this time-step "k"
        Aux_constraints = [Aux_constraints,...
            (ones(scenarios,1)*inflexible).*y{k} == ones(scenarios,1)*(inflexible.*y{k}(1,:))...
            y{k}(:,end) == 1];
        
        %         Define DVs for generators started up in this node
        startup_DV{k} = binvar(scenarios,num_gen,'full');
        if k==1
            Aux_constraints = [Aux_constraints,...
                startup_DV{k} == y{k}];
        else
            % These 2 constraints model the startup, it's easy to verify
            % that they indeed do:
            Aux_constraints = [Aux_constraints,...
                startup_DV{k} >= y{k} - y{k-1},...
                startup_DV{k} >= zeros(scenarios,num_gen)];
        end
        
        
        
        
        
        %% Constraints:
        
        for i=1:num_gen
            Constraints_Gen_limits = [Constraints_Gen_limits,...
                y{k} .* (ones(scenarios, 1) * Gen_limits_active(:,1)') <= xa{k} <= y{k} .* (ones(scenarios,1) * Gen_limits_active(:,2)'), ...  % Constraint (18b)
                y{k} .* (ones(scenarios, 1) * Gen_limits_reactive(:,1)') <= xr{k} <= y{k} .* (ones(scenarios,1) * Gen_limits_reactive(:,2)'), ...  % Constraint (18b)
                ];
        end
        
        
        if k == 1
            for i = 1: num_gen
                for j = k + 1: min(k + Updowntime_limits(i, 1) - 1, stages)  % Constraint (21c)
                    Constraints_Updown_time = [Constraints_Updown_time, ...
                        y{k}(:, i) <= y{j}(:, i)];                                          % Constraint (21a)
                end
                for j = k + 1: min(k + Updowntime_limits(i, 2) - 1, stages)  % Constraint (21d)
                    Constraints_Updown_time = [Constraints_Updown_time, ...
                        y{k}(:, i) <= ones(scenarios, 1) - y{j}(:, i)];             % Constraint (21b)
                end
            end
        end
        
        
        if k > 1
            Constraints_Ramp_limits = [Constraints_Ramp_limits, ...
                xa{k} - xa{k - 1} <= y{k-1} .* (ones(scenarios, 1) * Ramp_limits(:, 1)') ...
                + (y{k} - y{k - 1}) .* (ones(scenarios, 1) * Gen_limits_active(:, 1)'), ... % Constraint (19a)
                xa{k - 1} - xa{k} <= y{k-1} .* (ones(scenarios, 1) * Ramp_limits(:, 2)') ...
                + (y{k - 1} - y{k}) .* (ones(scenarios, 1) * Gen_limits_active(:, 1)'), ... % Constraint (19b)
                ];
            
            for i = 1: num_gen
                for j = k + 1: min(k + Updowntime_limits(i, 1) - 1, stages)  % Constraint (20d)
                    Constraints_Updown_time = [Constraints_Updown_time, ...
                        y{k}(:, i) - y{k - 1}(:, i) <= y{j}(:, i)];                                          % Constraint (20a)
                end
                for j = k + 1: min(k + Updowntime_limits(i, 2) - 1, stages)  % Constraint (20e)
                    Constraints_Updown_time = [Constraints_Updown_time, ...
                        y{k}(:, i) - y{k - 1}(:, i) <= ones(scenarios, 1) - y{j}(:, i)];             % Constraint (20b)
                end
            end
        end
        
        
        
        %% Compute linear expressions (inertia and FR):
        for m =1: scenarios
            [~, ind_Pw(m)] = min( abs( LUT_Pw_vw_Hsmax(:,1)./1e6 - sum(Wind_tree_active{k}(m,:),2)./Wind_capacity));
            Hs_max(m,k) = LUT_Pw_vw_Hsmax(ind_Pw(m), 3)/(1e6*20)*Wind_capacity;
            
            Aux_constraints = [Aux_constraints,...
                0 <= Hs(m,k) <= Hs_max(m,k)...
                Hs(m,k) <= 100];    %0.2];
        end
        if H_sv_switch == 1
            H = [H (y{k}*(H_g.*Gen_limits_active(:,2)))/f_o + Hs(s,k)];
        else
            H = [H (y{k}*(H_g.*Gen_limits_active(:,2)))/f_o];
        end
        % This way works to define FR, by using 2 constraints:
        FR{k} = sdpvar(scenarios,num_gen,'full');
        Aux_constraints = [Aux_constraints,...
            FR{k} <= (ones(scenarios,1)*Gen_limits_active(:,2)')-xa{k}
            FR{k} <= (ones(scenarios,1)*(Gen_limits_active(:,2)-Gen_limits_active(:,1))').*y{k} % This constraint forces the generators to provide zero FR if the unit is off
            0 <= FR{k} <= 0.2];
        Total_FR_by_qss = [Total_FR_by_qss sum(FR{k},2)];
        
        Dem(k) =  (Demand_active{k} * net.loadMat ) *ones(num_bus,1);
        
        %% Define the nodal costs:
        Cost_node = horzcat(Cost_node,...
            sum((ones(scenarios, 1) * stc') .* startup_DV{k}, 2)... % Startup costs
            + sum((ones(scenarios, 1) * NLHR') .* y{k}, 2)... % fixed generation costs
            + sum((ones(scenarios, 1) * HRS') .* xa{k}, 2)... % variable generation costs 'Enter' - sum((ones(scenarios, 1) * (HRS./HRS)'*0.00001) .* FR{k}, 2)... 
            + VOLL*sum(Load_curtailed_active{k},2)); % load shed cost
    end
    
    %         Remove the inertia from the outaged generator:
    H = H - ones(scenarios,stages)*(FreqRespTarget*H_L)/f_o;
    
    
    %% Frequency-security constraints
    for k=1:stages
        % q-s-s constraint (with damping):
        qss_constraints = [qss_constraints,...
            Total_FR_by_qss(:,k) >= 0.52 - D*Dem(k)*f_ss_lim];
    end
    if FreC == 1
        % Rocof constraint:
        Rocof_constraints = [Rocof_constraints,...
            FreqRespTarget/(2*Rocof_max) <= H];
        for k=1:stages
            % For nadir:
            for n=1:scenarios
                Nadir_constraints = [Nadir_constraints,...
                    norm([(H(n,k)-Total_FR_by_qss(n,k));
                    2*sqrt(FreqRespTarget^2*Td_unique/(4*nadir_req)-FreqRespTarget*Td_unique*D*Dem(k)/4);
                    sqrt(FreqRespTarget*Td_unique*Gamma)*Hs(n,k)]) <= (H(n,k)+Total_FR_by_qss(n,k))];
            end
        end
    end
    %% VS constraints
    for k=1:stages
        %             Gamma_eq{k} = [];
        for n_GFL = 1:num_GFL
            Pw_eq{k}(:,n_GFL) = (Wind_tree_active{k}(:,num_GFM+n_GFL) - Wind_curtailed_active{k}(:,num_GFM+n_GFL))/Base;
            Qw_eq{k}(:,n_GFL) = Qw{k}(:,n_GFL)/Base;
            
            for n_GFL2 = 1:num_GFL
                if n_GFL2 ~= n_GFL
                    Pw_eq{k}(:,n_GFL) =  Pw_eq{k}(:,n_GFL) +...
                        (Wind_tree_active{k}(:,n_GFL2)- Wind_curtailed_active{k}(:,n_GFL2))/Base*...
                        LUT_VS(1,num_GFL+(n_GFL-1)*(num_GFL)+(n_GFL2));
                    Qw_eq{k}(:,n_GFL) =  Qw_eq{k}(:,n_GFL) +...
                        Qw{k}(:,n_GFL2)/Base*...
                        LUT_VS(1,num_GFL+(n_GFL-1)*(num_GFL)+(n_GFL2));
                end
                for n_GFM = 1:num_GFM
                    Pw_eq{k}(:,n_GFL) =  Pw_eq{k}(:,n_GFL) +...
                        (Wind_tree_active{k}(:,n_GFM))/(1)*...
                        LUT_VS(1+n_GFM,num_GFL+(n_GFL-1)*(num_GFL-1)+(n_GFL2))*...
                        (Wind_tree_active{k}(:,n_GFL2)- Wind_curtailed_active{k}(:,n_GFL2))/Base;
                end
                for n_gen = 1:num_gen
                    Pw_eq{k}(:,n_GFL) =  Pw_eq{k}(:,n_GFL) +...
                        y{k}(:,n_gen)*LUT_VS(1+num_GFM+n_gen,num_GFL+(n_GFL-1)*(num_GFL-1)+(n_GFL2))*...
                        (Wind_tree_active{k}(:,n_GFL2)- Wind_curtailed_active{k}(:,n_GFL2))/Base;
                end
            end
            Gamma_eq{k}(:,n_GFL) = LUT_VS(1,n_GFL);
            for n_GFM = 1:num_GFM
                if n_GFM ~= price_GFM
                Gamma_eq{k}(:,n_GFL) = Gamma_eq{k}(:,n_GFL)+(Wind_tree_active{k}(:,n_GFM))/(1)*LUT_VS(1+n_GFM,n_GFL);   %Base in gen is 1 [GW]
                end
            end
            for n_gen = 1:num_gen
                if n_gen ~= price_g
                    Gamma_eq{k}(:,n_GFL) = Gamma_eq{k}(:,n_GFL) + y{k}(:,n_gen)*LUT_VS(1+num_GFM+n_gen,n_GFL);
                end
            end
        end
        if VS == 1
            for n_GFL = 1:num_GFL
                VS_constraints = [VS_constraints, ...
                    norm([Pw_eq{k}(:,n_GFL);Qw_eq{k}(:,n_GFL)]) <= (Qw_eq{k}(:,n_GFL)+Gamma_eq{k}(:,n_GFL)/2)];
            end
        end
    end
    

    
    %% SSS constraints
    for k=1:stages
        Lambda{k} = LUT_SSS(1);
        for n_GFM = 1:num_GFM
            if n_GFM ~= price_GFM
                Lambda{k} = Lambda{k} + LUT_SSS(1+n_GFM)*(Wind_tree_active{k}(:,n_GFM))/(2);  %GFM base = 1 GW, gen
                Lambda{k} = Lambda{k} + LUT_SSS(1+num_GFM+num_gen+n_GFM)*(Wind_tree_active{k}(:,n_GFM))/(2);
            end
        end
        for n_gen = 1:num_gen
            if n_gen ~= price_g
                Lambda{k} = Lambda{k} + LUT_SSS(1+num_GFM+n_gen)*y{k}(:,n_gen) + LUT_SSS(1+num_GFM*2+num_gen+n_gen)* ...
                    y{k}(:,n_gen).*mean((Wind_tree_active{k}(:,num_GFM+1:end)),2)/Base;
            end
        end
        Lambda{k} = Lambda{k} + LUT_SSS(1+(num_GFM+num_gen)*2+1)* ...
            mean((Wind_tree_active{k}(:,num_GFM+1:end)),2)/Base;  %- Wind_curtailed_active{k}(:,num_GFM+1:end)

        if SSS == 1
            SSS_constraints = [SSS_constraints, Lambda{k} >= 2.5];
        end
    end
    %% SCC constraints
    for k=1:stages
        x_SCC{k} = [ones(scenarios,1) y{k} mean((Wind_tree_active{k}(:,1:end)),2)];
        for n_bus = 1:num_bus 
            if sum(n_bus == I_sc_C)>0
                for m = 1:scenarios
                    Isc{k}(m,n_bus) = LUT_SCC_SOC_C(:,n_bus)'*x_SCC{k}(m,:)' -norm(LUT_SCC_SOC{n_bus}*x_SCC{k}(m,:)');
                end
%                 Isc{k}(:,n_bus) = LUT_SCC(:,n_bus)'*x_SCC{k}'; 
            end
            if SCC == 1  && sum(n_bus == I_sc_C)>0      
                SCC_constraints = [SCC_constraints, Isc{k}(:,n_bus) >= Isc_lim(n_bus)];
            end
        end
    end
    
    time.BuildingModel = toc;
    
    
    %% Solve optimisation
    
    tic
    
    Objective = sum(sum(Cost_node));
    Constraints = [
        Aux_constraints ...
        Constraints_Gen_limits ...
        Constraints_Ramp_limits...
        Voltage_constraints...
        Constraints_Updown_time ...
        Node_constraints ...
        Network_constraints ...
        SOCP_constraints ...
        qss_constraints...
        Rocof_constraints...
        Nadir_constraints ...
        VS_constraints ...
        SSS_constraints ...
        SCC_constraints
        ];

    
    options = sdpsettings('solver','gurobi','debug',1, 'verbose', 2);
    options.gurobi.MIPGap = 1e-3;
    options.gurobi.MIPFocus = 2;
    options.gurobi.Presolve = 2;
    options.gurobi.LogFile = 'LogFile';
    options.gurobi.QCPDual = 1;
    options.gurobi.TimeLimit = 1000;
    options.gurobi.DisplayInterval = 10;
    options.gurobi.PreSparsify = 1;
    fprintf('--- Starting optimisation ---\n')
    solution = optimize(Constraints,Objective, options)
    time.Optimisation = toc;
    [model, recoverymodel] = export(Constraints, Objective, sdpsettings('solver', 'Gurobi+'));

    
    
    %% Analyse results
    tic
    
    sol.H = value(H);
    %     sol.Hv = value(Hv);
    sol.Hs = value(Hs);
    %     sol.PLoss = value(PLoss);
    %     sol.SoC = value(SoC);
    sol.Rocof_diff = sol.H - FreqRespTarget/(2*Rocof_max);
    
    sol.Cost = [];
    sol.Cost_StartUp = [];
    sol.Cost_NLHR = [];
    sol.Cost_HRS = [];
    sol.V = [];
    sol.Cost_VOLL_active = [];

    for k=1:stages
        sol.qss_diff(:,k) = value(Total_FR_by_qss(:,k)) -FreqRespTarget + f_ss_lim*D*Dem(k);
        sol.Total_FR_by_qss(:,k) = value(Total_FR_by_qss(:,k));
        
        sol.V{k} = value(V{k});
        sol.Demand(k) = sum(Demand_active{k});
        sol.Wind(:,k) = sum(Wind_tree_active{k});
        %         sol.PV(k) = sum(PV_tree_active{k});
        %
        %         sol.P_in(:,k) = value(x_in_a{k});
        %         sol.P_battery{k} = value(x_battery_a{k});
        sol.xa{k} = value(xa{k});
        sol.xr{k} = value(xr{k});
        sol.y{k} = value(y{k});
        sol.startup_DV{k} = value(startup_DV{k});
        sol.FR{k} = value(FR{k});
        %         sol.FR_total{k} = sum(value(FR{k}),2);
        
        sol.PG{k} = value(PG{k});
        sol.Pw_eq{k} = value(Pw_eq{k});
        sol.Qw_eq{k} = value(Qw_eq{k});
        sol.Qw{k} = value(Qw{k});
        sol.Gamma_eq{k} = value(Gamma_eq{k});
        for n_GFL = 1:num_GFL
            sol.VS_diff{k}(:,n_GFL) = value((Qw_eq{k}(:,n_GFL)+Gamma_eq{k}(:,n_GFL)/2)...
                - norm([Pw_eq{k}(:,n_GFL);Qw_eq{k}(:,n_GFL)]));
        end
        sol.Lambda{k} = value(Lambda{k});
        sol.Isc{k} = value(Isc{k}');
        
        
        
        sol.QG{k} = value(QG{k});
        sol.PD{k} = value(PD{k});
        sol.QD{k} = value(QD{k});
        sol.Wind_curtailed_active{k} = sum(value(Wind_curtailed_active{k}));
        sol.Wind_curtailed_reactive{k} = value(Wind_curtailed_reactive{k});
        %         sol.PV_curtailed_active{k} = value(PV_curtailed_active{k});
        %         sol.PV_curtailed_reactive{k} = value(PV_curtailed_reactive{k});
        sol.Load_curtailed_active{k} = value(Load_curtailed_active{k});
        sol.Load_curtailed_reactive{k} = value(Load_curtailed_reactive{k});

        sol.P_node{k} = value(P_node{k});
        sol.Q_node{k} = value(Q_node{k});
        
        sol.Cost = horzcat(sol.Cost,...
            sum((ones(scenarios , 1) * stc') .* sol.startup_DV{k}, 2)... % Startup costs
            + sum((ones(scenarios, 1) * NLHR') .* sol.y{k}, 2)... % fixed generation costs
            + sum((ones(scenarios, 1) * HRS') .* sol.xa{k}, 2)... % variable generation costs
            + tau*(VOLL*sum(sol.Load_curtailed_active{k},2)));
        

        
        sol.Cost_StartUp = horzcat(sol.Cost_StartUp,...
            sum((ones(scenarios,1)*stc').*sol.startup_DV{k},2));
        sol.Cost_NLHR = horzcat(sol.Cost_NLHR,...
            sum((ones(scenarios,1)*NLHR').*sol.y{k},2));
        sol.Cost_HRS = horzcat(sol.Cost_HRS,...
            sum((ones(scenarios,1)*HRS').*sol.xa{k},2));
        sol.Cost_VOLL_active = horzcat(sol.Cost_VOLL_active,...
            tau*(VOLL*sum(sol.Load_curtailed_active{k},2)));
        
        
        sol.left_side_nadir{k} = value(H(:,k)).*value(Total_FR_by_qss(:,k));
        sol.right_side_nadir{k} = value(FreqRespTarget^2*Td_unique/(4*nadir_req)-FreqRespTarget*Td_unique*D*Dem(k)/4 ...
            + FreqRespTarget*Td_unique*Gamma* Hs(:,k).^2/4);
        sol.nadir_diff{k} = sol.left_side_nadir{k}-sol.right_side_nadir{k};

    end
    sol.Cost_mean = mean(sol.Cost);
    
    
    time.GetSolution = toc;
    
    %     clearvars -except Wind_tree Demand options sol solution time d days alpha beta H_sv_switch FreC sigma0
    %     clearvars -except Wind_tree Demand options sol solution time d days IIS
    %
    % %     cd('Solution_uGrid')
    % %     save(['Solution_IBG_' num2str(alpha) '_BESS_' num2str(beta) '_FDC_' num2str(FreC) '.mat'])
    % %     cd('..\')
    %
    %     clearvars -except IIS sol
    
end

% Isc_real = Isc_calculate(cell2mat(sol.y'),sol.Wind./num_wind);
% sol.SCC_vr = sum(sum((abs(Isc_real))<Isc_lim, 2)>0)/24;
% save(['Isc_real_wind' num2str(Wind_capacity) '.mat'], 'Isc_real')
Isc_reg = sol.Isc';
% save(['Isc_reg_wind' num2str(Wind_capacity) '.mat'], 'Isc_reg')

sol.FC_vr = sum(cell2mat(sol.nadir_diff)<0)/24;
sol.VS_vr = sum(sum(cell2mat(sol.VS_diff')<0, 2)>0)/24;
sol.SSS_vr = sum(cell2mat(sol.Lambda)<2.5)/24;


%% Plot
% figure(1)
% hold on
% plot(sum(cell2mat(sol.y'),2))
% % 
% figure(2)
% plot([1:24], [sol.Demand]./max(sol.Demand))
% hold on
% plot([1:24], [sol.Wind]./max(sol.Wind))
% plot([1:24], [sol.Wind-cell2mat(sol.Wind_curtailed_active)]./[sol.Demand])
% 
% plot([1:24], cell2mat(sol.Lambda))
% plot([1:24], cell2mat(sol.nadir_diff)-0.8)


% 
% figure(3)
% % plot([1:39], min(sol.Isc,[],2))
% hold on
% plot([1:39], min(abs(Isc_real),[],1))


% cd('Solution_Price_Stages\')
% save(['Sol_['  num2str(FreC) num2str(VS) num2str(SCC) num2str(SSS) '][' ...
%     num2str(H_sv_switch) num2str(VS_Q) num2str(Wind_capacity)...
%     '][pGFM_' num2str(price_GFM) '][stage_' num2str(stage0) '].mat'], 'sol')
% cd('..\')

if Num_iter > 1
%     clear
    clearvars -except Num_iter Wind_iter HsVQ_iter
%     clc
end
