clear
Num_iter = 1;       % 1 or 2^4
Wind_iter = 1;      %1 or 6:1-6


for stage0 = 1
    
% stage0 = 3;
stageN = 24;         % 1/24

for price_g = [0]        % 0 no price; g-th price
for price_GFM = [0]
for i = 0:Num_iter-1
    if Num_iter == 1
        binary_i = '0000';   %['  num2str(FreC) num2str(VS) num2str(SCC) num2str(SSS) ']
    else
        binary_i = dec2base(i,2,log2(Num_iter))
    end
    FreC = str2double(binary_i(1));             % frequency constraint, 1/0: on/off
%     FreC = 1;
    
    VS = str2double(binary_i(2));
    
    SCC = str2double(binary_i(3));
    SSS = str2double(binary_i(4));
    
    for j = 1:Wind_iter
        if Wind_iter == 1
            Wind_capacity = 5;          % manually define
            HsVQ_iter = 1;
        else
            Wind_capacity = j;   % [GW]
            HsVQ_iter = 4;
        end
        
        for k = 0:HsVQ_iter-1
            if HsVQ_iter == 1
                H_sv_switch = 0;        % manually define
                VS_Q = 1;               % manually define
            else
                binary_k = dec2base(k,2,2)
                H_sv_switch = str2double(binary_k(1));           
                VS_Q = str2double(binary_k(2));
            end
            
            % The units here are GW, k£/GW and k£ to keep the range of variables closer
            % num_ccgt = 0;
            % num_ocgt = 10;
            
            %% Frequency requirements:
            f_o = 50; % Nominal frequency, Hz
            nadir_req = 0.8; % Units: Hz
            Rocof_max = 0.5*2; % Hz/s
            f_ss_lim = 0.5; %[Hz]
            D = 0.005;
            
            % alpha = 3;  %for tuning the IBG's penetration
            % beta =  alpha;  %battery
            sigma0 = 0;   %uncertainty Level 0.1
            Gamma = 8.2639541898631562e-9;
            I_sc_C = [12,18,27];
            tol=1e-7; % Tolerance for the "implies" conditions in nadir
            %
            Base = 0.100;         % [GW]
            
            
            
            
            
            
            %% Forecasts:
            cd('Data')
            load('LUT_Pw_vw_Hsmax.mat')
            % load('WindTurbineCharacteristics')
            load('Demand_39_node_MILP_varying2.mat')
            Demand_active = 1e-3 * Demand_active; % devided by 1000MW
            Demand_reactive = 1e-3 *Demand_reactive; % devided by 1000MW
            [num_load, ~] = size(Demand_active);
            
            load('ScenarioTree_39_node_MILP_wind_1st.mat')
            % scenarios = 1;
            scenarios = size(Scenario_tree_active,1);
            Wind_scenarios_active = 1e-3 * Scenario_tree_active.*Wind_capacity*1e3./sum(max(Scenario_tree_active,[],3)); % devided by 1000MW
            Wind_scenarios_reactive = 1e-3 * Scenario_tree_reactive.*Wind_capacity*1e3./sum(max(Scenario_tree_active,[],3)); % devided by 1000MW
            [~, num_wind, ~] = size(Scenario_tree_active);
            
            % PV_capacity = 100*alpha;  %MW
            % load('ScenarioTree_14_node_SOCP_PV_1s.mat')
            % PV_scenarios_active = 1e-3*PV_tree_active*PV_capacity; % GW
            % PV_scenarios_reactive = 1e-3*PV_tree_reactive*PV_capacity; % GW
            % [~, num_PV, ~] = size(PV_tree_active);
            
            days = 1;
            stages = 24;
            
            % Split data in days:
            for i=1:size(Demand_active, 2)/stages
                Demand_active_day_matrix = Demand_active(:,(i-1)*stages+1:i*stages);
                Demand_reactive_day_matrix = Demand_reactive(:,(i-1)*stages+1:i*stages);
                Wind_scenarios_day_active_matrix = Wind_scenarios_active(:,:,(i-1)*stages+1:i*stages);
                Wind_scenarios_day_reactive_matrix = Wind_scenarios_reactive(:,:,(i-1)*stages+1:i*stages);
                
                %     PV_scenarios_day_active_matrix = PV_scenarios_active(:,:,(i-1)*24+1:i*24);
                %     PV_scenarios_day_reactive_matrix = PV_scenarios_reactive(:,:,(i-1)*24+1:i*24);
                for j=1:stages
                    Demand_active_day_cell{j} = Demand_active_day_matrix(:,j)';
                    Demand_reactive_day_cell{j} = Demand_reactive_day_matrix(:,j)';
                    Wind_scenarios_day_active_cell{j} = Wind_scenarios_day_active_matrix(:,:,j);
                    Wind_scenarios_day_reactive_cell{j} = Wind_scenarios_day_reactive_matrix(:,:,j);
                    
                    %         PV_scenarios_day_active_cell{j} = PV_scenarios_day_active_matrix(:,:,j);
                    %         PV_scenarios_day_reactive_cell{j} = PV_scenarios_day_reactive_matrix(:,:,j);
                end
                Demand_day_active{i} = Demand_active_day_cell;
                Demand_day_reactive{i} = Demand_reactive_day_cell;
                Wind_scenarios_day_active{i} = Wind_scenarios_day_active_cell;
                Wind_scenarios_day_reactive{i} = Wind_scenarios_day_reactive_cell;
                
                %     PV_scenarios_day_active{i} = PV_scenarios_day_active_cell;
                %     PV_scenarios_day_reactive{i} = PV_scenarios_day_reactive_cell;
                
                clear Demand_active_day_matrix Demand_reactive_day_matrix;
                clear Demand_active_day_cell Demand_reactive_day_cell;
                clear Wind_scenarios_day_active_matrix Wind_scenarios_day_reactive_matrix;
                clear Wind_scenarios_day_active_cell Wind_scenarios_day_reactive_cell;
                
                %     clear PV_scenarios_day_active_matrix PV_scenarios_day_reactive_matrix;
                %     clear PV_scenarios_day_active_cell PV_scenarios_day_reactive_cell;
            end
            
            
            % Equiprobable scenarios:
            prob_tree = 1/scenarios*ones(scenarios,stages);
            
            
            %% Generation costs:
            % (In the form)
            % c = [cost_gen1 cost_gen2 cost_gen3...]';
            NLHR = [4.5,3,3,3,3,3,3,4.5,3,0.0001]'; % k�/h fixed generation cost
            HRS = [47,200,200,200,200,200,200,47,200,10]';   % variable generation cost k�/1000MWh
            stc = [10 0.001 0.001 0.001 0.001 0.001 0.001 10 0.001 0]'; % k� Start up cost
            
            %cost_in = [10];
            num_gen = length(HRS);
            
            %% Frequency characteristics (To be filled later)
            H_g = [5*ones(1, num_gen)]'; % Inertia constants, units: s
            Td = [10*ones(1, num_gen)]; % Delivery time of FR, units: s
            %
            FreqRespTarget = 0.33; %42; % Max Power Infeed, units: GW. 
            H_L = 5; % Inertia constant of largest generator, units: s
            
            %% Capacities and limits:
            % Generation limits:
            % (In the form)
            % Gen_limits = [G1_min, G1_max;
            %               G2_min, G2_max;
            %               G3_min, G3_max;
            %               ...
            Gen_limits_active = [[250,677.871,650,632,508,650,560,540,830].*0.3 1000;...
                [250,677.871,650,632,508,650,560,540,830,1000]*1]' / 1000; % devided by 1000MW
            Gen_limits_reactive = [-[250,677.871,650,632,508,650,560,540,830,1000];[250,677.871,650,632,508,650,560,540,830,1000]]' / 1000;
            % % Gen_limits_OCGT_active = [200/2*0.3 200/2*0.3 140/2*0.3 140/2*0.3 100/2*0.3 100/2*0.3 100/2*0.3 100/2*0.3 ;
            % %     200/2 200/2 140/2 140/2 100/2 100/2 100/2 100/2 ]'/1000;
            % Gen_limits_OCGT_active = [60*0.3 60*0.3 55*0.3 55*0.3 45*0.3 45*0.3 40*0.3 40*0.3;
            %     60 60 55 55 45 45 40 40]'/1000;
            % Gen_limits_CCGT_reactive = [100*-0.05*ones(1,num_ccgt); 100*0.05*ones(1,num_ccgt)]';
            % % Gen_limits_OCGT_reactive = [0 0 -40/2 -40/2 0 0 -6/2 -6/2; 10/2 10/2 50/2 50/2 40/2 40/2 24/2 24/2]'/1000;
            % Gen_limits_OCGT_reactive = [0 0 0 -40/2 -40/2 -40/2 -6/2 -6/2; 10/2 10/2 10/2 50/2 50/2 50/2 40/2 40/2 ]'/1000;
            
            
            % P_in_limits_active = [-0.08 0.08];
            % P_in_limits_reactive = [-0.03 0.03];
            
            % Ramp limits:
            % (In the form)
            % Ramp_limits = [Ramp_down1, Ramp_up1;
            %                Ramp_down2, Ramp_up2;
            %                Ramp_down3, Ramp_up3;
            %                ...
            % Ramp_CCGT = [0.03*ones(1,num_ccgt); 0.03*ones(1,num_ccgt)]';
            % Ramp_OCGT = [0.02*ones(1,num_ocgt); 0.02*ones(1,num_ocgt)]';
            % Ramp_limits = [Ramp_CCGT;
            %               Ramp_OCGT];
            
            Ramp_limits = [0.3,0.2,0.2,0.2,0.2,0.2,0.2,0.3,0.2,0.025;
                0.3,0.2,0.2,0.2,0.2,0.2,0.2,0.3,0.2,0.025]';   % in GW/h
            Updowntime_limits = [4,0,0,0,0,0,0,4,0,4;
                1,0,0,0,0,0,0,1,0,1]';
            
            %% Battery
            % Rating_battery = [-0.05 0.05].*beta;  %[GW]
            % Cap_battery = 0.15*beta;    %[GWh]
            % Hv_max = num_PV*Rating_battery(2)/(2*Rocof_max);
            % Td_battery = 0.5;
            
            %% Other parameters
            VOLL = 30e3; % Units: k?/GWh
            tau = 1; % 1 hour time step
            
            inflexible = [1,0,0,0,0,0,0,1,0,1]; % 1 if unit is inflexible after DA, 0 otherwise
            
            % Initial_commitment = [zeros(1,num_gen)]'; % It seems that this variable is not used in TwoStage program
            
            %% Error checks
            
            
            % if length(Demand)~=stages
            %     error('The length of vector Demand must be equal to the number of stages (the stages come from Coursework2.m)')
            % end
            
            % if length(Initial_commitment)~=num_gen
            %     error('The lenght of vector "Initial_commitment" must be equal to the number of generators')
            % end
            
            if size(Gen_limits_active,1)~=num_gen
                error('Matrices "Gen_limits_active" and "Ramp_limits" must have as many rows as generators defined')
            end
            if size(Gen_limits_active,2)~=2
                error('Matrices "Gen_limits_active" and "Ramp_limits" must only have 2 columns')
            end
            if any(size(Gen_limits_active)~=size(Ramp_limits))
                error('There is a problem with the size of matrix "Gen_limits_active" or "Ramp_limits"')
            end
            if any(size(Gen_limits_active)~=size(Gen_limits_reactive))
                error('There is a problem with the size of matrix "Gen_limits_active" or "Gen_limits_reactive"')
            end
            
            %%
            clear i Scenario_tree
            
            cd('..\')
            save('SystemParameters.mat')
            TwoStage_MILP
        end
    end
end
end
end
end