clear all
clc
% Vectors showing the position in the network of generators, loads and wind
% turbines

%                                    Line code
%          Bus bus  R    X   1/2 B   = 1 for lines
%           nl nr  pu   pu     pu    >1 or <1 tr. tap at bus nl

     

linedata =[ 1  2  0.0035 0.0411 0.6987/2 1
                1  39 0.001	0.025	0.75/2 1
                2  3 0.0013	0.0151	0.2572/2 1
                2  25 0.007	0.0086	0.146/2 1
                3  4	0.0013	0.0213	0.2214/2 1
                3	18 0.0011	0.0133	0.2138/2 1
                4	5 0.0008	0.0128	0.1342/2 1
                4  14  0.0008	0.0129	0.1382/2 1
                5	6  0.0002	0.0026	0.0434/2 1
                5	8  0.0008	0.0112	0.1476/2 1
                6	7  0.0006	0.0092	0.113/2 1
                6	11 0.0007	0.0082	0.1389/2 1
                7	8  0.0004	0.0046	0.078/2 1
                8	9  0.0023	0.0363	0.3804/2 1
                9	39  0.001	0.025	1.2/2 1
                10  11   0.0004	0.0043	0.0729/2 1
                10 	13  0.0004	0.0043	0.0729/2 1
                13	14	0.0009	0.0101	0.1723/2 1
                14	15 0.0018	0.0217	0.366/2 1
                15	16 0.0009	0.0094	0.171/2 1
                16	17  0.0007	0.0089	0.1342/2 1
                16	19  0.0016	0.0195	0.304/2 1
                16	21  0.0008	0.0135	0.2548/2 1
                16	24 0.0003	0.0059	0.068/2 1
                17	18	0.0007	0.0082	0.1319/2 1
                17	27	0.0013	0.0173	0.3216/2 1
                21	22 0.0008	0.014	0.2565/2 1
                22	23  0.0006	0.0096	0.1846/2 1
                23	24  0.0022	0.035	0.361/2 1
                25	26  0.0032	0.0323	0.531/2 1
                26 27 0.0014	0.0147	0.2396/2 1
                26	28 0.0043	0.0474	0.7802/2 1
                26 29 0.0057	0.0625	1.029/2 1
                28	29 0.0014	0.0151	0.249/2 1
                2   30  0   0.0181  0 1.025
                6 31 0 0.025 0 1.07
                10 32 0 0.02 0 1.07
                12 11 0.0016 0.0435 0 1.006
                12 13 0.0016 0.0435 0 1.006
                19 20 0.0007 0.0138 0 1.06
                19 33 0.0007 0.0142 0 1.07
                20 34 0.0009 0.018 0 1.009
                22 35 0 0.0143 0 1.025
                23 36 0.0005 0.0272 0 1
                25 37 0.0006 0.0232 0 1.025
                29 38 0.0008 0.0156 0 1.025
                ];




shunt_susceptances = [
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
    0
];
        
% linedata(:,3) = linedata(:,3) * 10;
% linedata(:,4) = linedata(:,4) * 10;
% linedata(:,5) = linedata(:,5) * 0;
% linedata(:,6) = ones(13,1);
% shunt_susceptances = shunt_susceptances * 0.1;

DC = 1;
if DC == 1
    [Ybr, Ysh] = create_Ybr(linedata, shunt_susceptances);
    Gbr = real(Ybr);
    Bbr = imag(Ybr);
    Gsh = real(Ysh);
    Bsh = imag(Ysh);
else
    [Ybus, Ysh] = create_Ybus(linedata, shunt_susceptances);
    Ybus_conj = conj(Ybus);
    Ysh_conj = conj(Ysh);
end
[Ylineij, Ylineji] = create_Yline(linedata, shunt_susceptances);
%[G, B] = create_admittance(linedata, shunt_susceptances);


B = create_Bbus(linedata);


num_bus = max(max(linedata(1:2, :)));
Vmin = ones(num_bus,1) * 0.9;
Vmax = ones(num_bus,1) * 1.1;

Pijmax = ones(num_bus,num_bus) * 1000;
Ilinemax = ones(20,1) * 1000;    % variable not used !!

S_limit = ones(num_bus,num_bus) * 10;

[num_lines, ~] = size(linedata);

net.gen = [30 31 32 33 34 35 36 37 38 39]; 
net.load = [3 4 7 8 12 15 16 18 20 21 23 24 25 26 27 28 29 31 39];
net.wind = [27 26 28 29];   % in the order of [GFM, GFL]
net.wind_GFL = [26 28 29];
num_GFL = size(net.wind_GFL,2);
net.wind_GFM = [27];
num_GFM = size(net.wind_GFM,2);

% net.PV = [];
% net.P_in = [];

% asset x bus
net.genMat = create_lookup_matrix(net.gen, num_bus);
net.loadMat = create_lookup_matrix(net.load, num_bus);
net.windMat = create_lookup_matrix(net.wind, num_bus);
% net.PVMat = create_lookup_matrix(net.PV, num_bus);
% net.P_inMat = create_lookup_matrix(net.P_in, num_bus);

save('NetworkParameters.mat')