clear all
clc
%% ========================================================================
%  Define simulation parameters
%  ========================================================================
%% Simulation setup (for the user)
%   number of converters
model.num = 2;

%% Processing
%   Eliminate unnecessary Simulink warnings
warning('off','Simulink:Masking:Image_IgnoreLocationInAutoscale');

%   Add paths
addpath(genpath([pwd,'/Images']));

%% Simulation Parameters (for the user - optional)
simu.T_start = 0;              % Simulation start time [s] 
simu.T_stop = 100;              % Simulation end time [s] 
simu.Sim_type = 'fixed';       % Simulation type: {fixed} or {variable} time step
simu.T_step = 5e-4;           % Simulation time step (if fixed) [s]
simu.Solver = 'Auto';          % Solver type: Auto, Discrete, Ode8, Ode5 - Ode1, Ode14x      
sim_run = 1;                        % Automatically run the simulation
sim_saveResults = 1;                % Save simulation results
sim_plotResults = 1;                % Plot simulation results
sim_saveTXTfiles = 1;               % Save results as .txt files

warning('off','all');    
ctrl_switch = 0;                    % select SM controllers (0-custom; 1-MATLAB)
avr_switch = 1;                     % select AVR controller (0-ST1a; 1-SEXS)
T_breaker = 35;

model.name = 'IEEE_39';
open_system(model.name);

controller=[4 2 4 4];

for i=1:model.num
    switch controller(i)
        case 1 %grid forming droop
            %switches
            sync_mode(i) = 1;         %source of the frequency reference (1: nominal freq, 2: PLL, 3: VIM)
            sw_outer(i) = 1;          %type of outer control (1: droop, 2: vi, 3: droop+vi)
            
            %enable the corresponding sybsystems
            droop_outer(i) = 1;
            vi_outer(i) = 0;
            viDroop_outer(i) = 0;
            PLL_sync(i) = 0;
            VIM_sync(i) = 0;
            cascade_ctr(i) = 1;
            
            
        case 2 %grid forming vi
            sync_mode(i) = 1;         %source of the frequency reference (1: nominal freq, 2: PLL, 3: VIM)
            sw_outer(i) = 2;          %type of outer control (1: droop, 2: vi, 3: droop+vi)
            
            %enable the corresponding sybsystems
            droop_outer(i) = 0;
            vi_outer(i) = 1;
            viDroop_outer(i) = 0;
            PLL_sync(i) = 0;
            VIM_sync(i) = 0;
            cascade_ctr(i) = 1;
            
        case 3 %grid forming vi+droop
            %switches
            sync_mode(i) = 1;         %source of the frequency reference (1: nominal freq, 2: PLL, 3: VIM)
            sw_outer(i) = 3;          %type of outer control (1: droop, 2: vi, 3: droop+vi)
            
            %enable the corresponding sybsystems
            droop_outer(i) = 0;
            vi_outer(i) = 0;
            viDroop_outer(i) = 1;
            PLL_sync(i) = 0;
            VIM_sync(i) = 0;
            cascade_ctr(i) = 1;

            
        case 4 %grid following droop with PLL
            %switches
            sync_mode(i) = 2;         %source of the frequency reference (1: nominal freq, 2: PLL, 3: VIM)
            sw_outer(i) = 1;          %type of outer control (1: droop, 2: vi, 3: vi+droop)
            
            %enable the corresponding subsystems
            droop_outer(i) = 1;
            vi_outer(i) = 0;
            viDroop_outer(i) = 0;
            PLL_sync(i) = 1;
            VIM_sync(i) = 0;
            cascade_ctr(i) = 1;
            
            
        case 5 %grid following droop with VIM
            %switches
            sync_mode(i) = 3;         %source of the frequency reference (1: nominal freq, 2: PLL, 3: VIM)
            sw_outer(i) = 1;          %type of outer control (1: droop, 2: vi, 3: vi+droop)
            
            %enable the corresponding subsystems
            droop_outer(i) = 1;
            vi_outer(i) = 0;
            viDroop_outer(i) = 0;
            PLL_sync(i) = 0;
            VIM_sync(i) = 1;
            cascade_ctr(i) = 1;
            
            
        case 6 %grid following vi with PLL
            %switches
            sync_mode(i) = 2;         %source of the frequency reference (1: nominal freq, 2: PLL, 3: VIM)
            sw_outer(i) = 2;          %type of outer control (1: droop, 2: vi, 3: vi+droop)
            
            %enable the corresponding subsystems
            droop_outer(i) = 0;
            vi_outer(i) = 1;
            viDroop_outer(i) = 0;
            PLL_sync(i) = 1;
            VIM_sync(i) = 0;
            cascade_ctr(i) = 1;
            
            
        case 7 %grid following vi with VIM
            %switches
            sync_mode(i) = 3;         %source of the frequency reference (1: nominal freq, 2: PLL, 3: VIM)
            sw_outer(i) = 2;          %type of outer control (1: droop, 2: vi, 3: vi+droop)
            
            %enable the corresponding subsystems
            droop_outer(i) = 0;
            vi_outer(i) = 1;
            viDroop_outer(i) = 0;
            PLL_sync(i) = 0;
            VIM_sync(i) = 1;
            cascade_ctr(i) = 1;
            
        case 8 %grid following vi+droop with PLL
            %switches
            sync_mode(i) = 2;         %source of the frequency reference (1: nominal freq, 2: PLL, 3: VIM)
            sw_outer(i) = 3;          %type of outer control (1: droop, 2: vi, 3: vi+droop)
            
            %enable the corresponding subsystems
            droop_outer(i) = 0;
            vi_outer(i) = 0;
            viDroop_outer(i) = 1;
            PLL_sync(i) = 1;
            VIM_sync(i) = 0;
            cascade_ctr(i) = 1;
            
            
        case 9 %grid following vi+droop with VIM
            %switches
            sync_mode(i) = 3;         %source of the frequency reference (1: nominal freq, 2: PLL, 3: VIM)
            sw_outer(i) = 3;          %type of outer control (1: droop, 2: vi, 3: vi+droop)
            
            %enable the corresponding subsystems
            droop_outer(i) = 0;
            vi_outer(i) = 0;
            viDroop_outer(i) = 1;
            PLL_sync(i) = 0;
            VIM_sync(i) = 1;
            cascade_ctr(i) = 1;
    end
end

% General convention: Separate lines for separate VSCs, separate column for
% separate phase

%% Base Values
Pb = 1000 * 1e6 * ones(model.num,1);
Ub = 345 * 1e3;
fb = 60;
wb = 2*pi*fb ;
wb_pu = 1;
cosPhi_b = cos(atan2(0.3,1));
Sb = (Pb ./ cosPhi_b);
Tb = (Sb ./ wb);
Vb = Ub;
Ib = (Sb ./ Ub);
Zb = (Vb ./ Ib);
Lb = (Zb ./ wb);
Cb = 1 ./ (Zb .* wb);
fg = fb; % Grid frequency [Hz]

%% Nominal Parameters
% VSC
switch model.num
    case 1
        Pn = 1000 * 1e6;            % Nom. VSC power [W]
    case 2
        Pn = [125;1000] * 1e6;      % Nom. VSC power [W]
    case 3
        Pn = [1050;719;700] * 1e6;      % Nom. VSC power [W]
    case 4
        Pn = [1000;1000;1000;1000] * 1e6;      % Nom. VSC power [W]
end
cosPhi_n = cos(atan2(0.3, 1));  % Nom. cos(phi)
Un = 345 * 1e3;                 % Nom. phase-to-phase VSC voltage [V]
fn = 60;                        % Nom. frequency [Hz]
wn = 2*pi*fn;                   % Nom. angular velocity [rad/s]
Sn = Pn / cosPhi_n;             % Nom. apparent power [VA]
Un_dc = 640*1e3;                % Nom. DC voltage [V]

% Low-pass filter
Rf_pu = 0.005 * ones(1,model.num);             % Low-pass filter resistance Rf [p.u.]
Lf_pu = 0.15 * ones(1,model.num);             % Low-pass filter inductance Lf [p.u.]
Cf_pu = 0.066* ones(1,model.num);             % Low-pass filter capacitance Cf [p.u.]


% Loads
P_load = 830 * 1e6;        % Load active power P_load [W]
Q_load = 0;          % Load reactive power Q_load [VAr]
% ---------------------- %
DeltaP_load = 100 * 1e6; % Delta load active power [W]
DeltaQ_load = 100 * 1e6;            % Delta load reactive power [VAr]

% Transformers
R_transformer_pu = 0.005 * Sb ./ Sn;    % Transformer resistances [p.u]
L_transformer_pu = 0.15 * Sb ./ Sn;     % Transformer inductances [p.u]

R_transformer = R_transformer_pu .* Zb;
L_transformer = L_transformer_pu .* Lb;

% Lines
r_line = 0.03;                      % Line resistance [Ohm/km]
x_line = 0.3;                       % Line inductance [Ohm/km]
l_line = x_line / wn;
c_line = 10e-9;                    % Line shunt capacitance [F/km]
line_len = [50 50];      % Line lengths [km]


% "Dispatcher" Set Points
P_set = [0.2;0.6;0.2;0.2];                 % Active power set point for VSC [p.u]
Q_set = [0;0;0;0];                   % Reactive power set point for VSC [p.u]
Eg_set = [1;1;1;1];                  % RMS voltage set point for VSC [p.u]
    
Eg_set_dq0 = kron([1,0,0],Eg_set);

%% Matrix Transformations
M_clarke = sqrt(2/3) * [   1     ,    -1/2     ,    -1/2     ;...
    0     ,  sqrt(3)/2  , -sqrt(3)/2  ;...
    1/sqrt(2)  ,  1/sqrt(2)  ,  1/sqrt(2) ];

M_clarke_inv = sqrt(2/3) * [   1   ,    0        ,  sqrt(2)/2  ;...
    -1/2  ,  sqrt(3)/2  ,  sqrt(2)/2  ;...
    -1/2  ,  -sqrt(3)/2 ,  sqrt(2)/2 ];

theta0 = 0;
M_transform_inv = sqrt(2/3) * [   sin(theta0)     ,    cos(theta0)     ,    1/sqrt(2)     ;...
    sin(theta0-2*pi/3)     ,  cos(theta0-2*pi/3)  , 1/sqrt(2)  ;...
    sin(theta0+2*pi/3)     ,  cos(theta0+2*pi/3)  ,  1/sqrt(2) ];

%% Upper Control Parameters
% Voltage PI controller
Tr_v = 50 * 1e-3;                  % Time response [s]
D_v = 0.707;                       % Damping factor
Kp_v = 0.59;
Ki_v = 736;
Ti_v = Kp_v / Ki_v;

% Current PI controller
Tr_i = 5 * 1e-3;                   % Time response [s]
D_i = 0.707;                       % Damping factor
Kp_i = 1.27;
Ki_i = 14.3;
Kffi = 0;                         % Current feed forward (disabled)
Kffv = 1;                         % Voltage feed forward (enabled)
Ti_i = Kp_i / Ki_i;

% Droop controller
mp = 0.02 * ones(1,model.num);
nq = 0.001 * ones(1,model.num);

mp = 0.02 * ones(1,model.num);
nq = 0.001 * ones(1,model.num);


Tr_PLL=5e-3;
wn=5/Tr_PLL;
zeta=1;
Ti_PLL = 2*zeta/wn;
kp_PLL =-Ti_PLL*wn^2./Ub;

% Virtual inertia
% % constant parameters:
% H = 5 * ones(1,model.num);     % Constant of inertia [s]
% Kd = 350 * ones(1,model.num);  % Damping coefficient

% Parameters set for equivalence with droop:
H = [6.5;6.175;6.5;6.5];  % Constant of inertia [s]
Kd = 6*[1;1;1;1];        % Damping coefficient / mechanical power droop
Dw = 100;           % Damping (only for droop+inertia)

% DC BUS control
Cdc = 2e-3;
Tr_dc=100e-3;

% Virtual resistor
K_RV = 0.09;
W_RV = 16.66;

% Lead compensator
T2 = 0.0111;
T1 = 0.0333;

for i=1:model.num
    switch controller(i)
        case 5
            Ki_dc(i) = 0;    % deactivate the Integral controller of the DC side
            kp_dc(i) = 2;
            idcstar_enable(i)=1; %enable idcstar computation from P_set
            K_theta(i)=0.01;
            Kavr(i)=1;
            theta_0 = 0;
        case 6
            kp_dc(i) = 0.1;
            idcstar_enable(i)=1; %enable idcstar computation from P_set
            % AVR Gain for amplitude control
            Kavr(i) = 0.01;
            
            % Initial Angle Theta_0
            theta_0 = 0;
            % Angle-P-gain
            K_theta = 200/Un_dc;
        otherwise
            wn=5/Tr_dc;
            zeta=1;
            Ki_dc(i) = wn*wn*Cdc;
            kp_dc(i) =2*zeta*wn*Cdc;
            idcstar_enable(i)=0; %do not use a feedforward term for idc
            K_theta(i)=0;
            Kavr(i)=0;
            theta_0=0;
    end
end

% Virtual impedance
Rv_pu = 0;
Lv_pu = 0.2;

% PLL PI parameters (for grid-following VSCs and droop+inertia)
% PLL_Ki = 0.96;
% PLL_Kp = 0.96/90e-3;
PLL_Ki = 4.69*1;
Delta_PLL_Ki = 0;    
PLL_Kp = 0.4; %0.04

% Fast PLL PI parameters (only for measurement!)
FastPLL_Ki = 6634.6;
FastPLL_Kp = 114;

% Virtual induction machine emulator
f0_vim = 50;              % Initial rotor frequency [Hz]
w0_vim = 2*pi*f0_vim / wb;  % Initial angular rotor speed [p.u]
H_vim = 5.04;        % Inertia constant [s]
J_vim = 2 * H_vim * Sn * 1e-6 / (wb^2);  % Momentum of inertia
switch f0_vim
    case 50
        D_vim = 10 * ones(model.num,1);         % Damping constant [Nm/s]
    case 49.9
        D_vim = 2.7 * ones(model.num,1);         % Damping constant [Nm/s]
end

Rr_vim_pu = 0.0005;
Lr_vim_pu = 0.05;
Lm_vim_pu = 0.6;

Rr_vim = Rr_vim_pu * Zb;
Lr_vim = Lr_vim_pu * Lb;
Lm_vim = Lm_vim_pu * Lb;


% Control parameters
%   PD controller (w_slip)
Kp_vim = Rr_vim ./ Lr_vim;
Kd_vim = 0.001;
Nd_vim = 100;
%   Transfer function (Te)
Ke_vim_num = 3/2.*Rr_vim.*Lm_vim.^2;
Ke_vim_den = [Lr_vim.^2 , Rr_vim.*Lr_vim];
%   Inertia emulation (Delta_wr)
Inertia_vim_num = 1;
Inertia_vim_den = [J_vim , D_vim];

% VIM Iq/Id saturation limits
Iqd_sat = 0.25;    % Saturation current is 100% of VSC nominal current

% Switching time of a VIM
T_sync_switch = 0.01;

% Grid parameters
SCR = 20;
Usrc0_pu = 1;
X_grid_pu = Usrc0_pu/SCR;    % Grid inductance [p.u]
R_grid_pu = X_grid_pu*Lb(1)*wb/(10*Zb(1));         % Grid resistance [p.u]
L_grid_pu = X_grid_pu;

R_grid = R_grid_pu * Zb(1);
L_grid = L_grid_pu * Lb(1);
X_grid = L_grid * wb;

% Breaker parameters
R_breaker = 0.001;      % Breaker resistance [Ohm]
R_breaker_snb = 1e6;    % Snubber resistance [Ohm]
C_breaker_snb = inf;    % Snubber capacitance [F]

%% Initialization
% Grid voltage
Eg0_d = 1*ones(1,model.num)';
Eg0_q = 0*ones(1,model.num)';
Eg0_dq = [Eg0_d'; Eg0_q'; zeros(1,model.num)]';
Theta_E0 = [0;0;0];

% Load eqivalent
R_load = Ub.^2 / P_load;
L_load = Ub.^2 / (wb*Q_load);
Z_load = sqrt(R_load^2 + (wb*L_load)^2);
R_load_pu = R_load ./ Zb;
L_load_pu = L_load ./ Lb;

P0 = (Eg0_d.^2+Eg0_q.^2)./((R_load_pu + R_transformer_pu).^2 + (L_transformer_pu*wb_pu).^2).*(R_load_pu + R_transformer_pu);
Q0 = (Eg0_d.^2+Eg0_q.^2)./((R_load_pu + R_transformer_pu).^2 + (L_transformer_pu*wb_pu).^2).*(L_transformer_pu*wb_pu);

% Ig
Ig0_d = (P0 .* Eg0_d + Q0 .* Eg0_q) ./ (Eg0_d.^2+Eg0_q.^2); %
Ig0_q = (P0 .* Eg0_q - Q0 .* Eg0_d) ./ (Eg0_d.^2+Eg0_q.^2); %Initial current in the connexion inductance
Ig0_dq = [Ig0_d'; Ig0_q' ; zeros(1,model.num)]';

Is0_d = Ig0_d - Eg0_q .* (Cf_pu' * wb_pu); %% Irms
Is0_q = Ig0_q + Eg0_d .* (Cf_pu' * wb_pu);
Is0_dq = [Is0_d'; Is0_q'; zeros(1,model.num)]';

% Vconv
Vm0_d = (Rf_pu * Is0_d - Lf_pu * wb_pu * Is0_q) + Eg0_d;
Vm0_q = (Lf_pu * wb_pu * Is0_d + Rf_pu * Is0_q) + Eg0_q;
Vm0_dq = [Vm0_d'; Vm0_q'; zeros(1,model.num)]';

% Convert to abc values
Eg0_abc = (M_transform_inv * Eg0_dq')';
Vm0_abc = (M_transform_inv * Vm0_dq')';
Ig0_abc = (M_transform_inv * Ig0_dq')';
Is0_abc = (M_transform_inv * Is0_dq')';

Ws0 = wb;

%% Initial Conditions of Integrators (ICI)
% Current through filter inductance
ICI.Lf = Is0_abc / 1000;  %[kA]

% Voltage across filter capacitance
ICI.Cf = Eg0_abc / 1000;  %[kV]

% Phase of the voltage E0
ICI.Theta = Theta_E0;

% Current through the line
ICI.Line = Ig0_abc / 1000;  %[kA]

% d-axis current of the voltage-loop PI control
ICI.VoltagePI_d = ( Is0_d - Ig0_d .* Kffi + Eg0_q .* Cf_pu' * Ws0 / wb ) ./ Kp_v;

% q-axis current of the voltage-loop PI control
ICI.VoltagePI_q = (Is0_q - Ig0_q .* Kffi - Eg0_d .* Cf_pu' * Ws0 / wb ) ./ Kp_v;

% d-axis voltage of the current-loop PI control
ICI.CurrentPI_d = ( Vm0_d - Eg0_d .* Kffv + Is0_q .* Lf_pu' * Ws0 / wb ) ./ Kp_i;

% q-axis voltage of the current-loop PI control
ICI.CurrentPI_q = (Vm0_q - Eg0_q .* Kffv - Is0_d .* Lf_pu' * Ws0 / wb ) ./ Kp_i;


%% Initial Output of Time Delays (IOTD)

% Initial output of the converter's current feedback time-delay
IOTD.Ic = Is0_abc / 1000;  %[kA]

% Initial output of the upper controller's current feedback time-delay
IOTD.Is = Ig0_abc / 1000;  %[kA]

% Initial output of the converter's voltage time-delay
IOTD.Vs = Eg0_abc / 1000;  %[kV]

%% Time Delays
Tdelay_Is = 100e-6;
Tdelay_Ig = 100e-6;
Tdelay_Eg = 100e-6;
Tdelay_vdc = 100e-6;
Isat_max = 1;
Isat_min = -1;
wc = 0.1*wb;

%% TVI
I_max_pu=1.2;
I_thresh_pu=1 ;  % Output current limiting threshold to activate DZ0_vi (pu)
DX_DR=5; %DX_vi/DR_vi
Rc_pu = 0.005;
Lc_pu = 0.15;
Kp_Rvi_pu=((-2*(I_max_pu-I_thresh_pu)*(Rc_pu+Lc_pu*DX_DR))+sqrt((2*(I_max_pu-I_thresh_pu)*(Rc_pu+Lc_pu*DX_DR))^2-4*(I_max_pu-I_thresh_pu)^2*(1+DX_DR^2)*(Rc_pu^2+Lc_pu^2-(1/I_max_pu)^2)))/(2*(I_max_pu-I_thresh_pu)^2*(1+DX_DR^2));
kFF_TVI = 0;
%% dVOC parameters and rotation matrices

%initial dVOC angle
theta0 = 0*4.774/180*pi;


%Rotation matrix R_0 for the dVOC reference voltage
R_0 = [cos(theta0), -sin(theta0);
    sin(theta0),  cos(theta0)];

%90-degree rotation matrix J
J = [0 -1;1 0];

%Rotation matrix R(kappa) for mixed droop depending on the L/R ratio of the grid
rho = (L_transformer(1))/(R_transformer(1));
kappa = atan(rho*2*pi*50);


R_kappa = [cos(kappa) -sin(kappa);
    sin(kappa)  cos(kappa)];


%% Set VSC Mask Parameters
for i = (1:model.num)
    set_param([model.name, '/A1/IBR ',num2str(i), '/VSC ',num2str(i)],...
        'ind', num2str(i),...
        'Pn', num2str(Pn(i) / 1e6),...
        'cosPhi_n', num2str(cosPhi_n),...
        'Un', num2str(Un / 1e3),...
        'Un_dc', num2str(Un_dc / 1e3),...
        'fn', num2str(fn),...
        'Rf_pu', num2str(Rf_pu(i)),...
        'Lf_pu', num2str(Lf_pu(i)),...
        'Cf_pu', num2str(Cf_pu(i)),...
        'Kp_v', num2str(Kp_v),...
        'Ki_v', num2str(Ki_v),...
        'D_v', num2str(D_v),...
        'Tr_v', num2str(Tr_v),...
        'Kff_v', num2str(Kffv),...
        'Kp_i', num2str(Kp_i),...
        'Ki_i', num2str(Ki_i),...
        'D_i', num2str(D_i),...
        'Tr_i', num2str(Tr_i),...
        'Kff_i', num2str(Kffi),...
        'ICI_Lf', ['[ ',num2str(ICI.Lf(i,:)),' ]'],...
        'ICI_Cf', ['[ ',num2str(ICI.Cf(i,:)),' ]'],...
        'ICI_Theta', num2str(ICI.Theta(1)),...
        'ICI_Line', ['[ ',num2str(ICI.Line(i,:)),' ]'],...
        'ICI_VoltagePI_d', ['[ ',num2str(ICI.VoltagePI_d(i)),' ]'],...
        'ICI_VoltagePI_q', ['[ ',num2str(ICI.VoltagePI_q(i)),' ]'],...
        'ICI_CurrentPI_d', ['[ ',num2str(ICI.CurrentPI_d(i)),' ]'],...
        'ICI_CurrentPI_q', ['[ ',num2str(ICI.CurrentPI_q(i)),' ]'],...
        'Eg_set_dq0', ['[ ',num2str(Eg_set_dq0(i,:)),' ]'],...
        'Delta_Theta', num2str(0),...
        'Tdelay_Is', num2str(Tdelay_Is),...
        'Tdelay_Ig', num2str(Tdelay_Ig),...
        'Tdelay_Eg', num2str(Tdelay_Eg),...
        'P0', num2str(P0(i)),...
        'Q0', num2str(Q0(i)),...
        'P_set', num2str(P_set(i)),...
        'Q_set', num2str(Q_set(i)),...
        'mp', num2str(mp(i)),...
        'nq', num2str(nq(i)),...
        'H', num2str(H(i)),...
        'Kd', num2str(Kd(i)),...
        'Isat_max', num2str(Isat_max),...
        'Isat_min', num2str(Isat_min),...
        'wc', num2str(wc),...
        'Vm0_d', num2str(Vm0_d(i)),...
        'Vm0_q', num2str(Vm0_q(i)),...
        'Zb' , num2str(Zb(i)),...
        'Lb' , num2str(Lb(i)),...
        'Cb' , num2str(Cb(i)),...
        'Ki_dc', num2str(Ki_dc(i)),...
        'kp_dc', num2str(kp_dc(i)),...
        'idcstar_enable', num2str(idcstar_enable(i)),...
        'K_theta', num2str(K_theta(i)),...
        'Kavr', num2str(Kavr(i)),...
        'sync_mode',num2str(sync_mode(i)),...
        'sw_outer',num2str(sw_outer(i)),...
        'droop_outer',num2str(droop_outer(i)),...
        'vi_outer',num2str(vi_outer(i)),...
        'viDroop_outer',num2str(viDroop_outer(i)),...
        'PLL_sync',num2str(PLL_sync(i)),...
        'VIM_sync',num2str(VIM_sync(i)),...
        'cascade_ctr',num2str(cascade_ctr(i)),...
        'Inertia_vim_den',['[ ',num2str(Inertia_vim_den(i,:)),' ]'],...
        'Ke_vim_num',['[ ',num2str(Ke_vim_num(i,:)),' ]'],...        
        'Ke_vim_den',['[ ',num2str(Ke_vim_den(i,:)),' ]'],...
        'Sb',num2str(Sb(i)),...
        'Pb',num2str(Pb(i)),...
        'Ib',num2str(Ib(i)),...
        'Kp_vim',num2str(Kp_vim(i)));
end
%% ========================================================================